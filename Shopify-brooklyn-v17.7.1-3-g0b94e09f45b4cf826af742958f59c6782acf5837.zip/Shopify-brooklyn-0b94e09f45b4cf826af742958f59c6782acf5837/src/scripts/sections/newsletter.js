window.theme = window.theme || {};

theme.NewsletterSection = (function() {
  function Newsletter() {
    theme.styleTextLinks();
  }

  return Newsletter;
})();
