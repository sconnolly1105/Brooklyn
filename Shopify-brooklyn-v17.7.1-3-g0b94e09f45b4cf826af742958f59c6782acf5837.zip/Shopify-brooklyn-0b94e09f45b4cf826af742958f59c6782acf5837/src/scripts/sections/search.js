window.theme = window.theme || {};

theme.Search = (function() {
  function Search() {
    theme.equalHeights();
  }

  return Search;
})();
