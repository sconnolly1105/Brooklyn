window.theme = window.theme || {};

theme.PasswordContent = (function() {
  function PasswordContent() {
    theme.styleTextLinks();
  }

  return PasswordContent;
})();
