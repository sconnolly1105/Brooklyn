window.theme = window.theme || {};

theme.FeaturedContentSection = (function() {
  function FeaturedContent() {
    theme.styleTextLinks();
  }

  return FeaturedContent;
})();
