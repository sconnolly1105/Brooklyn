window.theme = window.theme || {};

theme.Product = (function() {
  function Product(container) {
    var $window = $(window);
    var $container = (this.$container = $(container));
    var sectionId = $container.attr('data-section-id');

    this.settings = {
      productPageLoad: false,
      preloadImage: false,
      enableHistoryState: true,
      namespace: '.productSection',
      sectionId: sectionId
    };

    this.selectors = {
      productMediaWrapper: '[data-product-single-media-wrapper]',
      productMediaGroup: '[data-product-single-media-group]',
      productMediaFlexWrapper: '[data-product-single-media-flex-wrapper]',
      productMediaTypeModel: '[data-product-media-type-model]',
      productMediaTypeVideo: '[data-product-media-type-video]',
      productThumbnails: '[data-product-thumbnails]',
      productThumbnail: '[data-product-thumbnail]',
      productFullDetails: '.product-single__full-details',
      productImageZoom: '[data-mfp-src]',
      productForm: '.add-to-cart__form',
      addToCart: '.btn--add-to-cart',
      addToCartText: '.btn__text',
      priceContainer: '[data-price-container]',
      productPrice: '#ProductPrice',
      SKU: '.variant-sku',
      priceA11y: '#PriceA11y',
      comparePrice: '#ComparePrice',
      comparePriceA11y: '#ComparePriceA11y',
      comparePriceWrapper: '.product-single__price--wrapper',
      quantityElements: '.js-quantity-selector, label + .js-qty',
      originalSelectorId: '#ProductSelect',
      singleOptionSelector: '.single-option-selector__radio',
      radioWrapper: '.radio-wrapper',
      meta: '.product-single__meta',
      productWrapper: '.product-single',
      shopifyPaymentButton: '.shopify-payment-button',
      slickDots: '[data-slick-dots]',
      slickNext: '[data-slick-next]',
      slickPrevious: '[data-slick-previous]',
      unitPrice: '[data-unit-price]',
      unitPriceBaseUnit: '[data-unit-price-base-unit]'
    };

    this.classes = {
      priceContainerUnitAvailable: 'price-container--unit-available',
      activeThumb: 'active-thumb',
      hide: 'hide'
    };

    this.slickSettings = {
      slide: this.selectors.productMediaFlexWrapper,
      accessibility: true,
      arrows: true,
      appendDots: this.selectors.slickDots,
      prevArrow: this.selectors.slickPrevious,
      nextArrow: this.selectors.slickNext,
      dots: true,
      infinite: false,
      adaptiveHeight: true,
      customPaging: function(slick, index) {
        var slideA11yString = theme.strings.productSlideLabel
          .replace('[slide_number]', index + 1)
          .replace('[slide_max]', slick.slideCount);

        var mediaA11yString = $(
          '[data-slick-index="' + index + '"]',
          this.$container
        ).data('slick-media-label');

        var ariaCurrent = index === 0 ? ' aria-current="true"' : '';
        return (
          '<a href="#ProductMediaGroup-' +
          sectionId +
          '" aria-label="' +
          slideA11yString +
          ' ' +
          mediaA11yString +
          '" aria-controls="slick-slide0' +
          index +
          '"' +
          ariaCurrent +
          '></a>'
        );
      }.bind(this)
    };

    this.slickTranslateDistance = 0;
    this.isCarouselActive = false;

    if (!$('#ProductJson-' + sectionId).html()) {
      return;
    }

    this.productSingleObject = JSON.parse(
      document.getElementById('ProductJson-' + sectionId).innerHTML
    );
    this.zoomType = $container.data('image-zoom-type');
    this.isStackedLayout = $container.data('stacked-layout');

    this.focusableElements = [
      'iframe',
      'input',
      'button',
      'video',
      '[tabindex="0"]'
    ].join(',');

    this.initBreakpoints();
    this.stringOverrides();
    this.initProductVariant();
    this.initStickyProductMeta();
    this.productThumbnailSwitch();
    this.initProductVideo();
    this._initModelViewerLibraries();
    this._initShopifyXrLaunch();

    if (this.zoomType) {
      this.productMediaZoom();
    }

    if (theme.settings.cartType === 'drawer') {
      ajaxCart.init({
        formSelector: '#AddToCartForm--' + sectionId,
        cartContainer: '#CartContainer',
        addToCartSelector: '#AddToCart--' + sectionId,
        enableQtySelectors: true,
        moneyFormat: theme.strings.moneyFormat
      });
    }

    $window
      .on('load' + this.settings.namespace, theme.initStickyProductMeta)
      .on(
        'resize' + this.settings.namespace,
        theme.debounce(this.initStickyProductMeta, 150).bind(this)
      );
  }

  Product.prototype = _.assignIn({}, Product.prototype, {
    initProductVariant: function() {
      var options = {
        $container: this.$container,
        enableHistoryState:
          this.$container.data('enable-history-state') || false,
        singleOptionSelector: this.selectors.singleOptionSelector,
        originalSelectorId:
          this.selectors.originalSelectorId + '--' + this.settings.sectionId,
        product: this.productSingleObject
      };

      this.variants = new slate.Variants(options);
      this.$container.on(
        'variantChange' + this.settings.namespace,
        this.productPage.bind(this)
      );
      this.$container.on(
        'variantMediaChange' + this.settings.namespace,
        this.showVariantMedia.bind(this)
      );
    },

    initBreakpoints: function() {
      var self = this;
      var $container = self.$container;
      self.zoomType = $container.data('image-zoom-type');

      enquire.register(theme.variables.mediaQuerySmall, {
        match: function() {
          self.createMediaCarousel();
          if (self.zoomType) {
            if ($(self.selectors.productImageZoom).length) {
              // remove event handlers for product zoom on mobile
              $(self.selectors.productImageZoom).off();
            }
          }
        },
        unmatch: function() {
          self.destroyMediaCarousel();

          if (self.zoomType) {
            // reinit product zoom
            self.productMediaZoom();
          }
        }
      });
    },

    _initModelViewerLibraries: function() {
      if (!this.$container.data('has-model')) return;

      var $modelViewerElements = $(
        this.selectors.productMediaTypeModel,
        this.$container
      );
      theme.ProductModel.init($modelViewerElements, this.settings.sectionId);
    },

    _initShopifyXrLaunch: function() {
      $(document).on(
        'shopify_xr_launch',
        function() {
          var $currentMedia = $(
            this.selectors.productMediaWrapper +
              ':not(.' +
              this.classes.hide +
              ')',
            this.$container
          );
          $currentMedia.trigger('xrLaunch');
        }.bind(this)
      );
    },

    initProductVideo: function() {
      var sectionId = this.settings.sectionId;

      $(this.selectors.productMediaTypeVideo, this.$container).each(function() {
        var $videoContainer = $(this);
        theme.ProductVideo.init($videoContainer, sectionId);
      });
    },

    stringOverrides: function() {
      // Override defaults in theme.strings with potential
      // template overrides

      theme.productStrings = theme.productStrings || {};
      $.extend(theme.strings, theme.productStrings);
    },

    resizeElements: function() {
      $(this.selectors.productGridImages, this.$container).imagesLoaded(
        function() {
          $(this.selectors.productGridImages, this.$container)
            .css('height', 'auto')
            .equalHeights();
        }
      );
    },

    showVariantMedia: function(evt) {
      var variant = evt.variant;
      var variantMediaId =
        this.settings.sectionId + '-' + variant.featured_media.id;

      var $newMedia = $(
        this.selectors.productMediaWrapper +
          '[data-media-id="' +
          variantMediaId +
          '"]'
      );

      this.triggerMediaChangeEvent(variantMediaId);

      var mediaIndex;

      if (variant && variant.featured_media) {
        this.setActiveThumbnail(variantMediaId);
      }

      if (
        theme.variables.bpSmall &&
        !this.$container.data('featured-product')
      ) {
        // Switch carousel slide, unless it's the first photo on load
        mediaIndex = $newMedia.closest('.slick-slide').data('slick-index');
        // Navigate to slide unless it's the first photo on load
        // If there is no index, slider is not initalized.
        if (_.isUndefined(mediaIndex)) {
          return;
        }

        if (mediaIndex !== 0 || theme.variables.productPageLoad) {
          $(this.selectors.productMediaGroup, this.$container).slick(
            'slickGoTo',
            mediaIndex
          );
        }
        // Switch media variant on thumbnail layout for desktop view;
        // When a media variant is updated on mobile view, update the
        // desktop view also.
        if (!this.isStackedLayout) {
          this.switchMedia(variantMediaId);
        }
      } else {
        if (this.isStackedLayout) {
          mediaIndex = $newMedia.closest('.slick-slide').index();
          // Scroll to/reorder media unless it's the first photo on load
          if (mediaIndex !== 0 || theme.variables.productPageLoad) {
            if (theme.variables.productPageSticky) {
              // Scroll to variant media
              $('html, body').animate(
                {
                  scrollTop: $newMedia.offset().top
                },
                250
              );
            } else {
              // Move selected variant media to top, preventing scrolling
              var currentScroll = $(document).scrollTop();
              $newMedia
                .closest(
                  $(this.selectors.productMediaFlexWrapper, this.$container)
                )
                .prependTo(
                  $(this.selectors.productMediaGroup, this.$container)
                );
              $(document).scrollTop(currentScroll);
            }
          }
        } else {
          // Switch media variant for thumbnail layout
          this.switchMedia(variantMediaId);
        }
      }

      if (!theme.variables.productPageLoad) {
        theme.variables.productPageLoad = true;
      }
    },

    triggerMediaChangeEvent: function(mediaId) {
      var $otherMedia = $(this.selectors.productMediaWrapper, this.$container);
      $otherMedia.trigger('mediaHidden');

      var $newMedia = $(
        this.selectors.productMediaWrapper,
        this.$container
      ).filter('#ProductMediaWrapper-' + mediaId);
      $newMedia.trigger('mediaVisible');
    },

    switchMedia: function(mediaId) {
      var $otherMedia = $(this.selectors.productMediaWrapper, this.$container);

      $otherMedia.addClass(this.classes.hide);
      var $newMedia = $(
        this.selectors.productMediaWrapper,
        this.$container
      ).filter('#ProductMediaWrapper-' + mediaId);
      $newMedia.removeClass(this.classes.hide);
    },

    productThumbnailSwitch: function() {
      var $productThumbnails = $(
        this.selectors.productThumbnails,
        this.$container
      ).find(this.selectors.productThumbnail);

      if ($productThumbnails.length) {
        // Switch the main media with one of the thumbnails
        // Note: this does not change the variant selected, just the media
        $productThumbnails
          .on(
            'click',
            function(evt) {
              evt.preventDefault();
              var newMediaId = $(evt.currentTarget).attr('data-media-id');

              this.switchMedia(newMediaId);
              this.setActiveThumbnail(newMediaId);
              this.triggerMediaChangeEvent(newMediaId);
            }.bind(this)
          )
          .on('keyup', this.handleMediaFocus.bind(this));
      }
    },

    handleMediaFocus: function(evt) {
      if (evt.keyCode !== 13) return;

      var mediaId = $(evt.currentTarget).data('media-id');

      $(
        this.selectors.productMediaWrapper +
          "[data-media-id='" +
          mediaId +
          "']",
        this.$container
      ).focus();
    },

    setActiveThumbnail: function(mediaId) {
      var $productThumbnails = $(
        this.selectors.productThumbnails,
        this.$container
      ).find(this.selectors.productThumbnail);

      if ($productThumbnails.length) {
        var $thumbnail = $(
          this.selectors.productThumbnail + "[data-media-id='" + mediaId + "']",
          this.$container
        );

        $productThumbnails.removeClass(this.classes.activeThumb);
        $thumbnail.addClass(this.classes.activeThumb);
      }
    },

    productMediaZoom: function() {
      if (
        !$(this.selectors.productImageZoom, this.$container).length ||
        theme.variables.bpSmall
      ) {
        return;
      }

      $(this.selectors.productImageZoom, this.$container).magnificPopup({
        type: 'image',
        mainClass: 'mfp-fade',
        closeOnBgClick: true,
        closeBtnInside: false,
        closeOnContentClick: true,
        tClose: theme.strings.zoomClose,
        removalDelay: 500,
        gallery: {
          enabled: true,
          navigateByImgClick: false,
          arrowMarkup:
            '<button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%"><span class="mfp-chevron mfp-chevron-%dir%"></span></button>',
          tPrev: theme.strings.zoomPrev,
          tNext: theme.strings.zoomNext
        }
      });
    },

    createMediaCarousel: function() {
      if (
        $(this.selectors.productMediaFlexWrapper).length < 2 ||
        !$(this.selectors.productMediaGroup, this.$container) ||
        this.isCarouselActive
      ) {
        return;
      }

      this.isCarouselActive = true;
      var dotStyle = {
        max: 9,
        width: 20
      };

      var focusTrapped = false;
      $(this.selectors.productMediaFlexWrapper, this.$container).on(
        'focusin',
        function() {
          if (focusTrapped) {
            return;
          }
          this.trapCarouselFocus($(this.selectors.productMediaGroup));
          focusTrapped = true;
        }.bind(this)
      );

      $(this.selectors.productMediaGroup, this.$container)
        .slick(this.slickSettings)
        .on(
          'beforeChange',
          function(event, slick, currentSlide, nextSlide) {
            this.updateCarouselDotsA11y(nextSlide);
            this.translateCarouselDots(slick.slideCount, nextSlide, dotStyle);
          }.bind(this)
        )
        .on(
          'afterChange',
          function(event, slick) {
            this.trapCarouselFocus(slick.$slider);
            // Let's do this after changing slides
            // Update featured media and active thumbnail on desktop
            // when changing slides
            this.setFeaturedMedia();
          }.bind(this)
        );

      if (this.isStackedLayout) return;
      var slideIndex = $(
        this.selectors.productMediaWrapper + ':not(.' + this.classes.hide + ')',
        this.$container
      )
        .closest(this.selectors.productMediaFlexWrapper)
        .data('slick-index');

      if (!slideIndex) return;
      $(this.selectors.productMediaGroup, this.$container).slick(
        'slickGoTo',
        slideIndex,
        true
      );
    },

    updateCarouselDotsA11y: function(nextSlide) {
      var $dotLinks = $(this.selectors.slickDots).find('a');
      $dotLinks
        .removeAttr('aria-current')
        .eq(nextSlide)
        .attr('aria-current', 'true');
    },

    translateCarouselDots: function(totalSlides, nextSlide, dotStyle) {
      if (totalSlides <= dotStyle.max) {
        return;
      }
      var calculatedTranslateDistance = 0;

      var maxTranslateDistance = (totalSlides - dotStyle.max) * dotStyle.width;
      if (nextSlide >= dotStyle.max - 1) {
        calculatedTranslateDistance =
          (nextSlide + 2 - dotStyle.max) * dotStyle.width;

        calculatedTranslateDistance =
          maxTranslateDistance < calculatedTranslateDistance
            ? maxTranslateDistance
            : calculatedTranslateDistance;
      }

      $(this.selectors.slickDots)
        .find('ul')
        .css('transform', 'translateX(-' + calculatedTranslateDistance + 'px)');
    },

    trapCarouselFocus: function($slider, removeFocusTrap) {
      if (!$slider) return;

      $slider
        .find('.slick-slide:not(.slick-active)')
        .find(this.focusableElements)
        .attr('tabindex', removeFocusTrap ? '0' : '-1');

      $slider
        .find('.slick-active')
        .find(this.focusableElements)
        .attr('tabindex', '0');
    },

    setFeaturedMedia: function() {
      var mediaId = $(this.selectors.productMediaGroup, this.$container)
        .find('.slick-slide.slick-active ' + this.selectors.productMediaWrapper)
        .attr('data-media-id');
      this.triggerMediaChangeEvent(mediaId);

      // Thumbnail layout only
      if (this.isStackedLayout) return;
      this.switchMedia(mediaId);
      this.setActiveThumbnail(mediaId);
    },

    destroyMediaCarousel: function() {
      if (
        !$(this.selectors.productMediaGroup, this.$container).length ||
        !this.isCarouselActive
      ) {
        return;
      }

      this.trapCarouselFocus(
        $(this.selectors.productMediaGroup, this.$container),
        true
      );

      $(this.selectors.productMediaGroup, this.$container).slick('unslick');
      this.isCarouselActive = false;
    },

    productPage: function(evt) {
      var moneyFormat = theme.strings.moneyFormat;
      var variant = evt.variant;
      var translations = theme.strings;

      if (variant) {
        // Display variant media on featured product
        if (!$('body').hasClass('template-product')) {
          if (variant.featured_media) {
            var variantMediaId =
              this.settings.sectionId + '-' + variant.featured_media.id;
            var $newMedia = $(
              this.selectors.productMediaWrapper +
                '[data-media-id="' +
                variantMediaId +
                '"]',
              this.$container
            );
            var $otherMedia = $(
              this.selectors.productMediaWrapper +
                ':not([data-media-id="' +
                variantMediaId +
                '"])',
              this.$container
            );

            $newMedia.removeClass(this.classes.hide);
            $otherMedia.addClass(this.classes.hide);
          }
        }

        $(this.selectors.priceContainer, this.$container).removeClass(
          'visibility-hidden ' + this.classes.priceContainerUnitAvailable
        );
        $(this.selectors.productPrice, this.$container).attr(
          'aria-hidden',
          'false'
        );
        $(this.selectors.priceA11y, this.$container).attr(
          'aria-hidden',
          'false'
        );

        // Select a valid variant if available
        if (variant.available) {
          // Available, enable the submit button, change text, show quantity elements
          $(this.selectors.addToCart, this.$container)
            .removeClass('disabled')
            .prop('disabled', false);
          $(this.selectors.addToCartText, this.$container).html(
            translations.addToCart
          );
          $(this.selectors.quantityElements, this.$container).show();
          $(this.selectors.shopifyPaymentButton, this.$container).show();

          // Update the full details link
          var $link = $(this.selectors.productFullDetails, this.$container);
          if ($link.length) {
            $link.attr(
              'href',
              this.updateUrlParameter($link.attr('href'), 'variant', variant.id)
            );
          }
        } else {
          // Sold out, disable the submit button, change text, hide quantity elements
          $(this.selectors.addToCart, this.$container)
            .addClass('disabled')
            .prop('disabled', true);
          $(this.selectors.addToCartText, this.$container).html(
            translations.soldOut
          );
          $(this.selectors.quantityElements, this.$container).hide();
          $(this.selectors.shopifyPaymentButton, this.$container).hide();
        }

        $(this.selectors.productPrice, this.$container)
          .html(theme.Currency.formatMoney(variant.price, moneyFormat))
          .show();

        // Also update and show the product's compare price if necessary
        if (variant.compare_at_price > variant.price) {
          $(this.selectors.comparePrice, this.$container).html(
            theme.Currency.formatMoney(variant.compare_at_price, moneyFormat)
          );
          $(this.selectors.comparePriceWrapper, this.$container).removeClass(
            this.classes.hide
          );
          $(this.selectors.productPrice, this.$container).addClass('on-sale');
          $(this.selectors.comparePriceWrapper, this.$container).attr(
            'aria-hidden',
            'false'
          );
          $(this.selectors.comparePriceA11y, this.$container).attr(
            'aria-hidden',
            'false'
          );
        } else {
          $(this.selectors.comparePriceWrapper, this.$container)
            .addClass(this.classes.hide)
            .attr('aria-hidden', 'true');
          $(this.selectors.productPrice, this.$container).removeClass(
            'on-sale'
          );
          $(this.selectors.comparePrice, this.$container).html('');
          $(this.selectors.comparePriceA11y, this.$container).attr(
            'aria-hidden',
            'true'
          );
        }

        if (variant.unit_price) {
          var $unitPrice = $(this.selectors.unitPrice, this.$container);
          var $unitPriceBaseUnit = $(
            this.selectors.unitPriceBaseUnit,
            this.$container
          );

          $unitPrice.html(
            theme.Currency.formatMoney(variant.unit_price, moneyFormat)
          );
          $unitPriceBaseUnit.html(this.getBaseUnit(variant));

          $(this.selectors.priceContainer, this.$container).addClass(
            this.classes.priceContainerUnitAvailable
          );
        }

        // Also Show SKU
        $(this.selectors.SKU).html(variant.sku);
      } else {
        // The variant doesn't exist, disable submit button.
        // This may be an error or notice that a specific variant is not available.
        // To only show available variants, implement linked product options:
        //   - http://docs.shopify.com/manual/configuration/store-customization/advanced-navigation/linked-product-options
        $(this.selectors.addToCart, this.$container)
          .addClass('disabled')
          .prop('disabled', true);
        $(this.selectors.addToCartText, this.$container).html(
          translations.unavailable
        );
        $(this.selectors.quantityElements, this.$container).hide();
        $(this.selectors.shopifyPaymentButton, this.$container).hide();

        $(this.selectors.priceContainer, this.$container).addClass(
          'visibility-hidden'
        );
        $(this.selectors.productPrice, this.$container).attr(
          'aria-hidden',
          'true'
        );
        $(this.selectors.priceA11y, this.$container).attr(
          'aria-hidden',
          'true'
        );
        $(this.selectors.comparePriceWrapper, this.$container).attr(
          'aria-hidden',
          'true'
        );
        $(this.selectors.comparePriceA11y, this.$container).attr(
          'aria-hidden',
          'true'
        );
      }
    },

    updateUrlParameter: function(url, key, value) {
      var re = new RegExp('([?&])' + key + '=.*?(&|$)', 'i');
      var separator = url.indexOf('?') === -1 ? '?' : '&';

      if (url.match(re)) {
        return url.replace(re, '$1' + key + '=' + value + '$2');
      } else {
        return url + separator + key + '=' + value;
      }
    },

    initStickyProductMeta: function() {
      var $meta = $(this.selectors.meta, this.$container);
      var $wrapper = $(this.selectors.productWrapper, this.$container);

      if ($meta.find('#shopify-product-reviews').length) {
        theme.variables.productPageSticky = false;
        return;
      }

      if (
        !$meta.length ||
        $(this.selectors.productMediaWrapper, this.$container).length < 2
      ) {
        return;
      }

      // Force detatch if already detached. Prevent layout issues.
      $meta.trigger('detach.ScrollToFixed');

      // Detach and stop if on mobile breakpoint
      if (theme.variables.bpSmall) {
        return;
      }

      var productCopyHeight = $meta.outerHeight();
      var productMediaGroupHeight = $(
        this.selectors.productMediaGroup,
        this.$container
      ).height();

      /*============================================================================
        Calculate when to detach fixed element to avoid content overlap.
        Subtract product copy height from the limit because plugin uses offset().top
      ==============================================================================*/
      var calcLimit = $wrapper.offset().top + $wrapper.height();
      calcLimit -= productCopyHeight;

      // Init sticky if desc shorter than images and fits in viewport
      if (
        productCopyHeight < productMediaGroupHeight &&
        productCopyHeight < $(window).height()
      ) {
        theme.variables.productPageSticky = true;
        $meta.scrollToFixed({
          limit: calcLimit
        });
      } else {
        theme.variables.productPageSticky = false;
      }
    },

    onUnload: function() {
      this.$container.off(this.settings.namespace);
      theme.ProductModel.removeSectionModels(this.settings.sectionId);
      theme.ProductVideo.removeSectionVideos(this.settings.sectionId);
      this.destroyMediaCarousel();
    },

    getBaseUnit: function(variant) {
      return variant.unit_price_measurement.reference_value === 1
        ? variant.unit_price_measurement.reference_unit
        : variant.unit_price_measurement.reference_value +
            variant.unit_price_measurement.reference_unit;
    }
  });

  return Product;
})();
