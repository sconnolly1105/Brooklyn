theme.slideshows = {};

theme.SlideshowSection = (function() {
  var classes = {
    headerWrapperTransparent: 'header-wrapper--transparent',
    isPaused: 'is-paused'
  };

  var selectors = {
    pause: '[data-pause]',
    headerWrapper: '[data-header-wrapper]'
  };

  function SlideshowSection(container) {
    theme.initCache();

    var $container = $(container);
    var sectionId = $container.attr('data-section-id');
    var slideshow = '#Hero-' + sectionId;
    this.$slideshow = $(slideshow);
    this.autoplay = this.$slideshow.data('autoplay');
    this.$headerWrapper = theme.cache.$siteHeader.closest(
      selectors.headerWrapper
    );

    theme.slideshows[slideshow] = new theme.Slideshow(this.$slideshow);

    // remove header absolute display if slideshow is empty
    if (!this.$slideshow.hasClass('hero')) {
      this.$headerWrapper.removeClass(classes.headerWrapperTransparent);
    }

    if (Shopify.designMode) {
      // Fix the slideshow height in the iOS theme editor
      this.setSlideshowHeight(this.$slideshow);
    }
  }

  SlideshowSection.prototype = _.assignIn({}, SlideshowSection.prototype, {
    onUnload: function() {
      this.$slideshow.slick('unslick');
    },

    onBlockSelect: function(evt) {
      var $slide = $('.slide--' + evt.detail.blockId);
      var slideIndex = $slide.attr('index');

      // Go to selected slide, pause autoplay
      this.$slideshow.slick('slickGoTo', slideIndex);

      if (this.autoplay) {
        this.$slideshow.slick('slickPause');
      }
    },

    onBlockDeselect: function() {
      var $pauseButton = this.$slideshow.find(selectors.pause);

      if (this.autoplay && $pauseButton.hasClass(classes.isPaused)) {
        this.$slideshow.slick('slickPlay');
      }
    },

    setSlideshowHeight: function($slideshow) {
      enquire.register(theme.variables.mediaQuerySmall, {
        match: function() {
          $slideshow.css('height', $(window.parent.document).height());
        },
        unmatch: function() {
          $slideshow.removeAttr('height');
        }
      });
    }
  });

  return SlideshowSection;
})();
