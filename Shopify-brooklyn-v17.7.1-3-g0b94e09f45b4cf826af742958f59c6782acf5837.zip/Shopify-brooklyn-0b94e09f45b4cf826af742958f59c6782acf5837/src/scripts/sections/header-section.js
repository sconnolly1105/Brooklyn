window.theme = window.theme || {};

theme.HeaderSection = (function() {
  var classes = {
    headerWrapperTransparent: 'header-wrapper--transparent'
  };

  function Header(container) {
    timber.drawersInit();
    theme.initCache();
    theme.fitNav();
    theme.resizeLogo();
    theme.searchModal();

    var $container = (this.$container = $(container));
    this.template = $container.attr('data-template');
    this.$headerWrapper = theme.cache.$siteHeader.closest(
      '[data-header-wrapper]'
    );

    // ajaxCart.init will run from Product.prototype when on the product page
    if (
      theme.settings.cartType === 'drawer' &&
      this.template.indexOf('product') === -1
    ) {
      ajaxCart.init({
        formSelector: '.add-to-cart__form',
        cartContainer: '#CartContainer',
        addToCartSelector: '.add-to-cart',
        enableQtySelectors: true,
        moneyFormat: theme.strings.moneyFormat
      });
    }

    theme.cache.$window.on('load', theme.resizeLogo);
    theme.cache.$window.on('resize', theme.debounce(theme.resizeLogo, 150));

    this.initSideBarDropDowns();
    this.updateHeaderTransparency();

    // Reorder & load events for all section
    // Only trigger when sections list contain slideshow
    $(document).on(
      'shopify:section:reorder shopify:section:load',
      this.updateHeaderTransparency.bind(this)
    );

    // setTimeout is added since we want to see the newest DOM structure
    // unLoad is triggered before the removal of the DOM
    $(document).on(
      'shopify:section:unload',
      function() {
        setTimeout(this.updateHeaderTransparency.bind(this));
      }.bind(this)
    );
  }

  Header.prototype = _.assignIn({}, Header.prototype, {
    onSelect: function() {
      this.handleDrawerOpenInEditor(event);
    },

    onDeselect: function() {
      timber.LeftDrawer.close(event);
    },

    handleDrawerOpenInEditor: function(event) {
      if (
        theme.cache.$siteNav.hasClass('site-nav--compress') ||
        theme.variables.bpSmall
      ) {
        setTimeout(function() {
          timber.LeftDrawer.drawerIsOpen = false;
          timber.LeftDrawer.open();
        }, 500);
      } else if (!theme.cache.$siteNav.hasClass('site-nav--compress')) {
        timber.LeftDrawer.drawerIsOpen = true;
        timber.LeftDrawer.close(event);
      }
    },

    initSideBarDropDowns: function() {
      var $toggleBtns = $('.mobile-nav__toggle-btn');
      // Setup aria attributes
      $toggleBtns.attr('aria-expanded', 'false');

      $toggleBtns.each(function() {
        var $button = $(this);
        $button.attr('aria-controls', $button.attr('data-aria-controls'));
      });

      $toggleBtns.on('click', function() {
        var $button = $(this);
        var currentlyExpanded = $button.attr('aria-expanded');
        var toggleState = false;
        // Updated aria-expanded value based on state pre-click
        if (currentlyExpanded === 'true') {
          $button.attr('aria-expanded', 'false');
        } else {
          $button.attr('aria-expanded', 'true');
          toggleState = true;
        }

        // Toggle that expands/collapses sublist
        $button
          .closest('.mobile-nav__has-sublist')
          .toggleClass('mobile-nav--expanded', toggleState)
          .next()
          .slideToggle();
      });
    },

    /**
     * Check whether the first section is slideshow
     * and enable transparency setting (header) is enabled
     */
    updateHeaderTransparency: function() {
      var $sectionsWrapper = theme.cache.$body.find('[data-sections-wrapper]');
      var $firstSection = $sectionsWrapper.find('[data-section-type]').first();

      this.$headerWrapper.removeClass(classes.headerWrapperTransparent);

      if (
        $firstSection.data('section-type') === 'slideshow-section' &&
        theme.cache.$siteHeader.data('transparent-header') === true
      ) {
        this.$headerWrapper.addClass(classes.headerWrapperTransparent);
      }
    }
  });

  return Header;
})();
