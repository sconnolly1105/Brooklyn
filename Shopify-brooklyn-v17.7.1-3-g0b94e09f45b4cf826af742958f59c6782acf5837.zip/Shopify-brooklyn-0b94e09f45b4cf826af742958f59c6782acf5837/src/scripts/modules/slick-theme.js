/*
 * Shopify JS for customizing Slick.js
 *   http://kenwheeler.github.io/slick/
 *   Untouched JS in assets/slick.min.js
 */

theme.Slideshow = (function() {
  'use strict';

  var selectors = {
    activeSlide: '.slick-active',
    heroAdaptTextWrap: '[data-hero-adapt-text-wrap]',
    heroDotsWrapper: '[data-hero-dots-wrapper]',
    heroImage: '[data-hero-image]',
    heroTextContent: '[data-hero-text-content]',
    pagination: '[data-slide-pagination]',
    pause: '[data-pause]',
    slickList: '.slick-list',
    slidePrevious: '[data-slide-previous]',
    slideNext: '[data-slide-next]',
    slides: '.slick-slide'
  };

  var classes = {
    heroSlideHidden: 'hero__slide--hidden',
    isPaused: 'is-paused'
  };

  function Slideshow($slider) {
    var $sliderWrapper = $slider.closest('[data-section-id]');
    var loadSlideA11yString = (this.loadSlideA11yString = $slider.data(
      'slide-nav-a11y'
    ));
    var activeSlideA11yString = (this.activeSlideA11yString = $slider.data(
      'slide-nav-active-a11y'
    ));

    this.$slider = $slider;

    // Default settings
    this.settings = {
      $element: $slider,
      accessibility: true,
      adaptHeight: $slider.data('adapt'),
      arrows: true,
      dots: true,
      slide: '[data-hero-slide]',
      /* eslint-disable shopify/jquery-dollar-sign-reference */
      prevArrow: $slider.find(selectors.slidePrevious),
      nextArrow: $slider.find(selectors.slideNext),
      appendDots: $slider.find(selectors.heroDotsWrapper),
      /* eslint-enable shopify/jquery-dollar-sign-reference */
      adaptiveHeight: true,
      draggable: false,
      fade: true,
      focusOnChange: false,
      isTouch: Modernizr.touch ? true : false,
      autoplay: $slider.data('autoplay'),
      autoplaySpeed: $slider.data('autoplayspeed'),
      customPaging: function(slick, index) {
        var labelString =
          index === 0 ? activeSlideA11yString : loadSlideA11yString;
        return (
          '<a href="' +
          $slider.attr('id') +
          '" aria-label="' +
          labelString.replace('[slide_number]', index + 1) +
          '" data-slide-number="' +
          index +
          '" data-slide-pagination aria-controls="SlickSlide' +
          (index + 1) +
          '"></a>'
        );
      }
    };

    this.cache = {
      $window: $(window),
      $heroImage: $slider.find(selectors.heroImage),
      $heroText: $slider.find(selectors.heroTextContent),
      $pauseButton: $slider.find(selectors.pause),
      $textWrapperMobile: $sliderWrapper.find(selectors.heroAdaptTextWrap)
    };

    this.currentActiveSlide = 0;

    /*
     * Init slick slider
     *   - Add any additional option changes here
     *   - https://github.com/kenwheeler/slick/#options
     */
    this.$slider
      .on(
        'init',
        function(event, slick) {
          this.onInit(slick);
        }.bind(this)
      )
      .on(
        'beforeChange',
        function(event, slick, currentSlide, nextSlide) {
          this.beforeChange(slick, currentSlide, nextSlide);
        }.bind(this)
      )
      .on(
        'afterChange',
        function(event, slick) {
          this.afterChange(slick);
        }.bind(this)
      );

    this.$slider.slick(this.settings);
  }

  Slideshow.prototype = _.assignIn({}, Slideshow.prototype, {
    onInit: function(obj) {
      this.$allSlides = obj.$slides;
      this.$activeSlide = obj.$slider.find(
        selectors.slides + selectors.activeSlide
      );
      this.$pagination = obj.$slider.find(selectors.pagination);

      if (!this.settings.isTouch) {
        obj.$slides.addClass(classes.heroSlideHidden);
        this.$activeSlide.removeClass(classes.heroSlideHidden);
      }

      if (this.settings.autoplay) {
        this.cache.$pauseButton.on('click', this.togglePause.bind(this));

        $(document).scroll(
          theme.debounce(
            function() {
              var slideshowOffsetY =
                obj.$slider.offset().top + obj.$slider.outerHeight();

              if (slideshowOffsetY < window.pageYOffset) {
                this.togglePauseAttributes(this.cache.$pauseButton, false);
                obj.$slider.slick('slickPause');
              } else if (!this.cache.$pauseButton.hasClass(classes.isPaused)) {
                this.togglePauseAttributes(this.cache.$pauseButton, true);
                obj.$slider.slick('slickPlay');
              }
            }.bind(this),
            250
          )
        );
      }

      // Prevent default slick behaviour of autoplaying on mouseleave
      obj.$slider.find(selectors.slickList).off('mouseleave.slick');

      if (this.settings.adaptHeight) {
        this.showMobileText(0);
      }

      this.slideshowA11ySetup(obj.$slider);
      this.applySlideColor(0, 1);
    },

    beforeChange: function(obj, currentSlide, nextSlide) {
      obj.$slider.attr('data-slide-index', nextSlide);

      if (!this.settings.isTouch) {
        obj.$slides.removeClass(classes.heroSlideHidden);
      }

      if (this.settings.adaptHeight) {
        this.showMobileText(nextSlide);
      }

      this.applySlideColor(nextSlide, currentSlide);

      this.$pagination.each(
        function(index, element) {
          var labelString =
            index === nextSlide
              ? this.activeSlideA11yString
              : this.loadSlideA11yString;

          labelString = labelString.replace('[slide_number]', index + 1);

          $(element).attr('aria-label', labelString);
        }.bind(this)
      );

      // Set upcoming slide as index
      this.currentActiveSlide = nextSlide;
    },

    afterChange: function(obj) {
      if (this.settings.isTouch) {
        return;
      }

      this.$activeSlide = this.$slider.find(
        selectors.slides + selectors.activeSlide
      );

      obj.$slides.addClass(classes.heroSlideHidden).attr('aria-hidden', true);

      this.$activeSlide
        .removeClass(classes.heroSlideHidden)
        .attr('aria-hidden', false);
    },

    keyboardNavigation: function(evt) {
      if (evt.keyCode === 37) {
        this.$slider.slick('slickPrev');
      }
      if (evt.keyCode === 39) {
        this.$slider.slick('slickNext');
      }
    },

    togglePause: function(evt) {
      var $pauseButton = $(evt.currentTarget);
      var isPaused = $pauseButton.hasClass(classes.isPaused);

      this.togglePauseAttributes($pauseButton, isPaused);

      if (this.settings.autoplay) {
        if (isPaused) {
          this.$slider.slick('slickPlay');
        } else {
          this.$slider.slick('slickPause');
        }
      }
    },

    togglePauseAttributes: function($pauseButton, isPaused) {
      if (this.settings.autoplay) {
        $pauseButton
          .toggleClass(classes.isPaused, !isPaused)
          .attr(
            'aria-label',
            isPaused
              ? $pauseButton.data('label-pause')
              : $pauseButton.data('label-play')
          );
      }
    },

    showMobileText: function(slideIndex) {
      var $allTextContent = this.cache.$textWrapperMobile.find(
        selectors.heroTextContent
      );
      var $currentTextContent = this.cache.$textWrapperMobile.find(
        '[data-index="' + slideIndex + '"]'
      );

      if (!$currentTextContent.length && this.$allSlides.length === 1) {
        this.cache.$textWrapperMobile.hide();
      } else {
        this.cache.$textWrapperMobile.show();
      }

      $allTextContent.hide();
      $currentTextContent.show();
    },

    // Apply when slideshow is in first position
    applySlideColor: function(nextSlideIndex, previousSlideIndex) {
      var prefixClassName = 'hero--color-';

      this.$slider
        .removeClass(prefixClassName + previousSlideIndex)
        .addClass(prefixClassName + nextSlideIndex);
    },

    slideshowA11ySetup: function($slider) {
      var $list = $slider.find(selectors.slickList);

      // When an element in the slider is focused
      // pause slideshow and set aria-live.
      $slider
        .on(
          'focusin mouseenter',

          function(evt) {
            if (
              !$slider.has(evt.target).length ||
              $list.attr('aria-live') === 'polite'
            ) {
              return;
            }

            $list.attr('aria-live', 'polite');
            if (this.settings.autoplay) {
              $slider.slick('slickPause');
            }
          }.bind(this)
        )
        .on(
          'focusout mouseleave',

          function(evt) {
            if ($slider.has(evt.relatedTarget).length) {
              return;
            }

            $list.removeAttr('aria-live');
            if (this.settings.autoplay) {
              // Only resume playing if the user hasn't paused using the pause
              // button
              if (!this.cache.$pauseButton.hasClass(classes.isPaused)) {
                $slider.slick('slickPlay');
              }
            }
          }.bind(this)
        )
        .on('keyup', this.keyboardNavigation.bind(this));

      $list.removeAttr('tabindex');

      this.$allSlides.each(function(index) {
        $(this)
          .attr('id', 'SlickSlide' + (index + 1))
          .attr('aria-hidden', true);
      });

      this.$activeSlide.attr('aria-hidden', false);

      if (this.$allSlides.length > 1) {
        this.$pagination.each(function() {
          $(this).on('click keyup', function(evt) {
            if (evt.type === 'keyup' && evt.which !== 13) return;

            evt.preventDefault();

            if (evt.type === 'keyup') {
              $slider.focus();
            }
          });
        });
      }
    }
  });

  return Slideshow;
})();
