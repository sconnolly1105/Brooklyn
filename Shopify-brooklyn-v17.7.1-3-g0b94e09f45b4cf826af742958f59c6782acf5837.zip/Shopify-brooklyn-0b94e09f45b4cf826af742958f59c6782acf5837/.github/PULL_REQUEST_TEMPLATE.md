### Purpose

_Provide a link to the relevant issue with the "fixes" keyword_

Fixes {issue_link}

### Approach

_Briefly explain why you chose this approach_

### Preview links

_Provide links to your test store using the `?preview_theme_id` parameter. This is to help reviewers tophat._

Demo store: https://{link}.myshopify.com/?preview_theme_id={id}

Editor: https://{link}.myshopify.com/admin/themes/{id}/editor

### More Information

_Any additional information which might be helpful for reviewers._

Pings here:
