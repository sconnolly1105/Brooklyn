---
name: Project report
about: Track theme updates related to a new feature or project
title: "[ProjectName] Title"
labels: "Project"
assignees: ""
---

### Goal

_Succinct outline of the update to the theme. Provide a Vault link to a project board, or reference to a larger theme rollout._

### Scope

_What templates, user flows or merchants will this affect?_

### More Information

_Any additional information which might be helpful. Are there related GitHub issues or project boards? How should someone setup their testing environment?_

### For issue makers

- [ ] Label this GitHub issue with a relevant `Project - *` label, or [make a new label](https://github.com/Shopify/brooklyn/labels).
