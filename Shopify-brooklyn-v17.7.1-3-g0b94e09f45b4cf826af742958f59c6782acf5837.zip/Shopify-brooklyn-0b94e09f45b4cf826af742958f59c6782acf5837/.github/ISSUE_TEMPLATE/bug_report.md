---
name: Bug report
about: Report an issue with this theme
title: ""
labels: "Bug"
assignees: ""
---

### Problem

_Succinct outline of the problem._

### Scope

_Is it only happening on one theme? Multiple themes? Is this related to a specific browser? etc_

### Expected vs Actual

_What do you expect to happen and what is actually happening instead? Screenshots ?_

### Reproduction Steps

_How to replicate the problem. Break it down into a numbered list, and/or link to a screencast with the last item in the list naming the expected vs. actual result. Screenshots, animated gif or video?_

### More Information

_Any additional information which might be helpful. Are there related GitHub issues? Commits you think might be responsible? Do you know why it's happening? Can you blame a specific piece of code?_

### Examples

_Link examples to themes affected. If a theme is unpublished, link the unpublished theme. Add related Zendesk tickets here as well_

Pings here:
