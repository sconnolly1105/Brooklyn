# Change Log
Version 9 of Highlight.js has reached EOL and is no longer supported.
Please upgrade or ask whatever dependency you are using to upgrade.
https://github.com/highlightjs/highlight.js/issues/2877

## v17.7.1 (2021-11-08)

#### 🐜 Bug fix
* [#1041](https://github.com/Shopify/brooklyn/pull/1041) Remove deprecated `dependencies` attribute from shopify-build pipelines ([@KaichenWang](https://github.com/KaichenWang))

#### 🌏 Translation
* [#1039](https://github.com/Shopify/brooklyn/pull/1039) Update translations: merchant ([@translation-platform[bot]](https://github.com/apps/translation-platform))
* [#1033](https://github.com/Shopify/brooklyn/pull/1033) Update translations: buyer ([@translation-platform[bot]](https://github.com/apps/translation-platform))
* [#1038](https://github.com/Shopify/brooklyn/pull/1038) Update translations: merchant ([@translation-platform[bot]](https://github.com/apps/translation-platform))

#### Committers: 2
- Kai ([@KaichenWang](https://github.com/KaichenWang))
- [@translation-platform[bot]](https://github.com/apps/translation-platform)
Version 9 of Highlight.js has reached EOL and is no longer supported.
Please upgrade or ask whatever dependency you are using to upgrade.
https://github.com/highlightjs/highlight.js/issues/2877

## v17.7.0 (2021-09-13)

#### 🚀 Enhancement
* [#1023](https://github.com/Shopify/brooklyn/pull/1023) Use money_with_currency filter for total prices ([@slucaskim](https://github.com/slucaskim))
* [#1026](https://github.com/Shopify/brooklyn/pull/1026) Place country/region selector before language selector ([@benkovy](https://github.com/benkovy))

#### 🐜 Bug fix
* [#1019](https://github.com/Shopify/brooklyn/pull/1019) Back to collection fix ([@ludoboludo](https://github.com/ludoboludo))

#### 🌏 Translation
* [#1032](https://github.com/Shopify/brooklyn/pull/1032) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#1031](https://github.com/Shopify/brooklyn/pull/1031) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#1029](https://github.com/Shopify/brooklyn/pull/1029) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#1025](https://github.com/Shopify/brooklyn/pull/1025) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 4
- Ben Kovacs ([@benkovy](https://github.com/benkovy))
- Lucas Kim ([@slucaskim](https://github.com/slucaskim))
- Ludo ([@ludoboludo](https://github.com/ludoboludo))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
Version 9 of Highlight.js has reached EOL and is no longer supported.
Please upgrade or ask whatever dependency you are using to upgrade.
https://github.com/highlightjs/highlight.js/issues/2877

## v17.6.0 (2021-05-13)

#### 🚀 Enhancement
* [#1005](https://github.com/Shopify/brooklyn/pull/1005) Convert currency selector to country selector ([@benkovy](https://github.com/benkovy))

#### 🌏 Translation
* [#1022](https://github.com/Shopify/brooklyn/pull/1022) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 2
- Ben Kovacs ([@benkovy](https://github.com/benkovy))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v17.5.0 (2021-04-30)

#### 🚀 Enhancement
* [#1008](https://github.com/Shopify/brooklyn/pull/1008) Add payment-terms liquid filter ([@bernardoamc](https://github.com/bernardoamc))

#### 🌏 Translation
* [#1011](https://github.com/Shopify/brooklyn/pull/1011) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#1012](https://github.com/Shopify/brooklyn/pull/1012) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#1009](https://github.com/Shopify/brooklyn/pull/1009) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 2
- Bernardo Araujo ([@bernardoamc](https://github.com/bernardoamc))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v17.4.1 (2021-04-14)

#### 🐜 Bug fix
* [#1006](https://github.com/Shopify/brooklyn/pull/1006) Only show variant title on cart page for non-default variants ([@NabeelChaudhry](https://github.com/NabeelChaudhry))
* [#1003](https://github.com/Shopify/brooklyn/pull/1003) Do not load cart on password page ([@martinamarien](https://github.com/martinamarien))
* [#1004](https://github.com/Shopify/brooklyn/pull/1004) escape og_description in meta tags ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))

#### 🌏 Translation
* [#1002](https://github.com/Shopify/brooklyn/pull/1002) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 4
- Lucas Lacerda ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))
- Martina Marien ([@martinamarien](https://github.com/martinamarien))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- [@NabeelChaudhry](https://github.com/NabeelChaudhry)

## v17.4.0 (2021-03-24)

#### 🚀 Enhancement
* [#997](https://github.com/Shopify/brooklyn/pull/997) Remove within: collection filter ([@tauthomas01](https://github.com/tauthomas01))

#### 🐜 Bug fix
* [#999](https://github.com/Shopify/brooklyn/pull/999) [Fix] Cart drawer routes ([@tauthomas01](https://github.com/tauthomas01))

#### 🌏 Translation
* [#995](https://github.com/Shopify/brooklyn/pull/995) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#996](https://github.com/Shopify/brooklyn/pull/996) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#993](https://github.com/Shopify/brooklyn/pull/993) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#994](https://github.com/Shopify/brooklyn/pull/994) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### 🏠 Internal
* [#992](https://github.com/Shopify/brooklyn/pull/992) Update Yarn with new package host ([@package-migrator-bot[bot]](https://github.com/apps/package-migrator-bot))

#### Committers: 3
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- [@package-migrator-bot[bot]](https://github.com/apps/package-migrator-bot)
- [@tauthomas01](https://github.com/tauthomas01)

## v17.3.0 (2021-03-03)

#### 🚀 Enhancement
* [#988](https://github.com/Shopify/brooklyn/pull/988) [Tax Inclusive Pricing] Use cart.taxes_included ([@benkovy](https://github.com/benkovy))
* [#983](https://github.com/Shopify/brooklyn/pull/983) Remove Youtube SDK from ProductVideo ([@tylerrowsell](https://github.com/tylerrowsell))

#### 🌏 Translation
* [#990](https://github.com/Shopify/brooklyn/pull/990) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#991](https://github.com/Shopify/brooklyn/pull/991) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#989](https://github.com/Shopify/brooklyn/pull/989) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#987](https://github.com/Shopify/brooklyn/pull/987) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 3
- Ben Kovacs ([@benkovy](https://github.com/benkovy))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- Tyler Rowsell ([@tylerrowsell](https://github.com/tylerrowsell))

## v17.2.4 (2021-02-22)

#### 🌏 Translation
* [#986](https://github.com/Shopify/brooklyn/pull/986) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#985](https://github.com/Shopify/brooklyn/pull/985) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#984](https://github.com/Shopify/brooklyn/pull/984) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v17.2.3 (2021-02-10)

#### 🌏 Translation
* [#982](https://github.com/Shopify/brooklyn/pull/982) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#980](https://github.com/Shopify/brooklyn/pull/980) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#979](https://github.com/Shopify/brooklyn/pull/979) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v17.2.2 (2021-01-20)

#### 🐜 Bug fix
* [#978](https://github.com/Shopify/brooklyn/pull/978) [RTE] Fix image size ([@tauthomas01](https://github.com/tauthomas01))
* [#977](https://github.com/Shopify/brooklyn/pull/977) [Slideshow] Autoplay focus issue ([@ludoboludo](https://github.com/ludoboludo))

#### 🌏 Translation
* [#976](https://github.com/Shopify/brooklyn/pull/976) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 3
- Ludo ([@ludoboludo](https://github.com/ludoboludo))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- [@tauthomas01](https://github.com/tauthomas01)

## v17.2.1 (2021-01-04)

#### 🐜 Bug fix
* [#969](https://github.com/Shopify/brooklyn/pull/969) Fix shopify build name ([@tauthomas01](https://github.com/tauthomas01))

#### 🌏 Translation
* [#973](https://github.com/Shopify/brooklyn/pull/973) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#972](https://github.com/Shopify/brooklyn/pull/972) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#970](https://github.com/Shopify/brooklyn/pull/970) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#971](https://github.com/Shopify/brooklyn/pull/971) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#968](https://github.com/Shopify/brooklyn/pull/968) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#966](https://github.com/Shopify/brooklyn/pull/966) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#967](https://github.com/Shopify/brooklyn/pull/967) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#962](https://github.com/Shopify/brooklyn/pull/962) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#965](https://github.com/Shopify/brooklyn/pull/965) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 2
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- [@tauthomas01](https://github.com/tauthomas01)

## v17.2.0 (2020-11-17)

#### 🚀 Enhancement
* [#961](https://github.com/Shopify/brooklyn/pull/961) Updated deprecated {{ shop.locale }} to use {{ request.locale.iso_code }} ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))

#### 🌏 Translation
* [#960](https://github.com/Shopify/brooklyn/pull/960) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#958](https://github.com/Shopify/brooklyn/pull/958) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#957](https://github.com/Shopify/brooklyn/pull/957) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 2
- Lucas Lacerda ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v17.1.0 (2020-10-29)

#### 🚀 Enhancement
* [#956](https://github.com/Shopify/brooklyn/pull/956) Add selling plan name and line item properties to cart and order page… ([@uditdesai](https://github.com/uditdesai))
* [#948](https://github.com/Shopify/brooklyn/pull/948) Remove deprecated languages ([@movermeyer](https://github.com/movermeyer))

#### 🌏 Translation
* [#955](https://github.com/Shopify/brooklyn/pull/955) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 3
- Michael Overmeyer ([@movermeyer](https://github.com/movermeyer))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- Udit Desai ([@uditdesai](https://github.com/uditdesai))

## v17.0.6 (2020-10-20)

#### 🌏 Translation
* [#954](https://github.com/Shopify/brooklyn/pull/954) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v17.0.5 (2020-10-14)

#### 🌏 Translation
* [#952](https://github.com/Shopify/brooklyn/pull/952) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#951](https://github.com/Shopify/brooklyn/pull/951) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#950](https://github.com/Shopify/brooklyn/pull/950) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v17.0.4 (2020-09-24)

#### 🌏 Translation
* [#947](https://github.com/Shopify/brooklyn/pull/947) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#946](https://github.com/Shopify/brooklyn/pull/946) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#945](https://github.com/Shopify/brooklyn/pull/945) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v17.0.3 (2020-09-10)

#### 🌏 Translation
* [#942](https://github.com/Shopify/brooklyn/pull/942) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v17.0.2 (2020-08-25)

#### 🌏 Translation
* [#940](https://github.com/Shopify/brooklyn/pull/940) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#939](https://github.com/Shopify/brooklyn/pull/939) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#938](https://github.com/Shopify/brooklyn/pull/938) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#935](https://github.com/Shopify/brooklyn/pull/935) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#936](https://github.com/Shopify/brooklyn/pull/936) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#933](https://github.com/Shopify/brooklyn/pull/933) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#931](https://github.com/Shopify/brooklyn/pull/931) Update configuration languages in translations.yml ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v17.0.1 (2020-07-28)

#### 🐜 Bug fix
* [#928](https://github.com/Shopify/brooklyn/pull/928) Add check before using page_image object ([@uditdesai](https://github.com/uditdesai))

#### 🌏 Translation
* [#930](https://github.com/Shopify/brooklyn/pull/930) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#932](https://github.com/Shopify/brooklyn/pull/932) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 2
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- Udit Desai ([@uditdesai](https://github.com/uditdesai))

## v17.0.0 (2020-07-20)

#### 💥 Breaking Change
* [#926](https://github.com/Shopify/brooklyn/pull/926) Update social sharing tags to use global page variables ([@uditdesai](https://github.com/uditdesai))

#### 🌏 Translation
* [#923](https://github.com/Shopify/brooklyn/pull/923) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#925](https://github.com/Shopify/brooklyn/pull/925) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### 🏠 Internal
* [#927](https://github.com/Shopify/brooklyn/pull/927) bump @shopify/theme-lint version to 3.1.0 ([@martinamarien](https://github.com/martinamarien))

#### Committers: 3
- Martina Marien ([@martinamarien](https://github.com/martinamarien))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- Udit Desai ([@uditdesai](https://github.com/uditdesai))

## v16.0.10 (2020-07-07)

#### 🌏 Translation
* [#922](https://github.com/Shopify/brooklyn/pull/922) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#919](https://github.com/Shopify/brooklyn/pull/919) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#920](https://github.com/Shopify/brooklyn/pull/920) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v16.0.9 (2020-06-09)

#### 🌏 Translation
* [#918](https://github.com/Shopify/brooklyn/pull/918) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v16.0.8 (2020-05-28)

#### 🌏 Translation
* [#915](https://github.com/Shopify/brooklyn/pull/915) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#913](https://github.com/Shopify/brooklyn/pull/913) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v16.0.7 (2020-05-20)

#### 🌏 Translation
* [#912](https://github.com/Shopify/brooklyn/pull/912) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#911](https://github.com/Shopify/brooklyn/pull/911) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#910](https://github.com/Shopify/brooklyn/pull/910) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v16.0.6 (2020-05-13)

#### 🌏 Translation
* [#907](https://github.com/Shopify/brooklyn/pull/907) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#906](https://github.com/Shopify/brooklyn/pull/906) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#905](https://github.com/Shopify/brooklyn/pull/905) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#904](https://github.com/Shopify/brooklyn/pull/904) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v16.0.5 (2020-05-07)

#### 🌏 Translation
* [#903](https://github.com/Shopify/brooklyn/pull/903) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#901](https://github.com/Shopify/brooklyn/pull/901) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#902](https://github.com/Shopify/brooklyn/pull/902) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#900](https://github.com/Shopify/brooklyn/pull/900) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#899](https://github.com/Shopify/brooklyn/pull/899) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#898](https://github.com/Shopify/brooklyn/pull/898) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#896](https://github.com/Shopify/brooklyn/pull/896) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#897](https://github.com/Shopify/brooklyn/pull/897) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#894](https://github.com/Shopify/brooklyn/pull/894) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#895](https://github.com/Shopify/brooklyn/pull/895) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v16.0.4 (2020-04-27)

#### 🌏 Translation
* [#893](https://github.com/Shopify/brooklyn/pull/893) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#892](https://github.com/Shopify/brooklyn/pull/892) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v16.0.3 (2020-04-22)

#### 🐜 Bug fix
* [#890](https://github.com/Shopify/brooklyn/pull/890) Fix featured-product for products with no media ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))
* [#889](https://github.com/Shopify/brooklyn/pull/889) Fix Brooklyn password subheading locale ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))

#### 🌏 Translation
* [#891](https://github.com/Shopify/brooklyn/pull/891) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#886](https://github.com/Shopify/brooklyn/pull/886) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#887](https://github.com/Shopify/brooklyn/pull/887) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#884](https://github.com/Shopify/brooklyn/pull/884) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#885](https://github.com/Shopify/brooklyn/pull/885) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#883](https://github.com/Shopify/brooklyn/pull/883) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#882](https://github.com/Shopify/brooklyn/pull/882) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#881](https://github.com/Shopify/brooklyn/pull/881) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#880](https://github.com/Shopify/brooklyn/pull/880) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#878](https://github.com/Shopify/brooklyn/pull/878) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#879](https://github.com/Shopify/brooklyn/pull/879) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#877](https://github.com/Shopify/brooklyn/pull/877) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#876](https://github.com/Shopify/brooklyn/pull/876) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#875](https://github.com/Shopify/brooklyn/pull/875) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#872](https://github.com/Shopify/brooklyn/pull/872) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#871](https://github.com/Shopify/brooklyn/pull/871) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### 🏠 Internal
* [#874](https://github.com/Shopify/brooklyn/pull/874) Fix localhost BrowserSync visible error on body ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))

#### Committers: 2
- Lucas Lacerda ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v16.0.2 (2020-04-02)

#### 🐜 Bug fix
* [#857](https://github.com/Shopify/brooklyn/pull/857) Fix variants not being added to cart via Featured Product section ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))

#### 🌏 Translation
* [#870](https://github.com/Shopify/brooklyn/pull/870) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#869](https://github.com/Shopify/brooklyn/pull/869) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#868](https://github.com/Shopify/brooklyn/pull/868) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#867](https://github.com/Shopify/brooklyn/pull/867) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#866](https://github.com/Shopify/brooklyn/pull/866) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#864](https://github.com/Shopify/brooklyn/pull/864) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#865](https://github.com/Shopify/brooklyn/pull/865) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#859](https://github.com/Shopify/brooklyn/pull/859) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#860](https://github.com/Shopify/brooklyn/pull/860) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#858](https://github.com/Shopify/brooklyn/pull/858) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#855](https://github.com/Shopify/brooklyn/pull/855) Update configuration languages in translations.yml ([@angelamchen](https://github.com/angelamchen))

#### Committers: 3
- Angela Chen ([@angelamchen](https://github.com/angelamchen))
- Lucas Lacerda ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v16.0.1 (2020-03-19)

#### 🌏 Translation
* [#854](https://github.com/Shopify/brooklyn/pull/854) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#853](https://github.com/Shopify/brooklyn/pull/853) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v16.0.0 (2020-03-13)

#### 💥 Breaking Change
* [#738](https://github.com/Shopify/brooklyn/pull/738) Rich Media : Master ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))

#### 🌏 Translation
* [#852](https://github.com/Shopify/brooklyn/pull/852) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#851](https://github.com/Shopify/brooklyn/pull/851) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#849](https://github.com/Shopify/brooklyn/pull/849) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#848](https://github.com/Shopify/brooklyn/pull/848) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#847](https://github.com/Shopify/brooklyn/pull/847) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#846](https://github.com/Shopify/brooklyn/pull/846) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#845](https://github.com/Shopify/brooklyn/pull/845) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#843](https://github.com/Shopify/brooklyn/pull/843) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#836](https://github.com/Shopify/brooklyn/pull/836) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 2
- Lucas Lacerda ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v15.3.0 (2020-03-04)

#### 🚀 Enhancement
* [#785](https://github.com/Shopify/brooklyn/pull/785) Add currency language selector ([@benkovy](https://github.com/benkovy))

#### 🌏 Translation
* [#835](https://github.com/Shopify/brooklyn/pull/835) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#832](https://github.com/Shopify/brooklyn/pull/832) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#831](https://github.com/Shopify/brooklyn/pull/831) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#830](https://github.com/Shopify/brooklyn/pull/830) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#828](https://github.com/Shopify/brooklyn/pull/828) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#827](https://github.com/Shopify/brooklyn/pull/827) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#818](https://github.com/Shopify/brooklyn/pull/818) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#813](https://github.com/Shopify/brooklyn/pull/813) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#812](https://github.com/Shopify/brooklyn/pull/812) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#807](https://github.com/Shopify/brooklyn/pull/807) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#800](https://github.com/Shopify/brooklyn/pull/800) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#798](https://github.com/Shopify/brooklyn/pull/798) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 2
- Ben Kovacs ([@benkovy](https://github.com/benkovy))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v15.2.8 (2020-02-18)

#### 🐜 Bug fix
* [#797](https://github.com/Shopify/brooklyn/pull/797) Move target_languages back to root of translation config ([@KaichenWang](https://github.com/KaichenWang))

#### 🌏 Translation
* [#799](https://github.com/Shopify/brooklyn/pull/799) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 2
- Kai ([@KaichenWang](https://github.com/KaichenWang))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v15.2.7 (2020-02-17)

#### 🌏 Translation
* [#796](https://github.com/Shopify/brooklyn/pull/796) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#795](https://github.com/Shopify/brooklyn/pull/795) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#794](https://github.com/Shopify/brooklyn/pull/794) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#793](https://github.com/Shopify/brooklyn/pull/793) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#789](https://github.com/Shopify/brooklyn/pull/789) Remove deprecated languages ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v15.2.6 (2020-02-11)

#### 🌏 Translation
* [#787](https://github.com/Shopify/brooklyn/pull/787) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#786](https://github.com/Shopify/brooklyn/pull/786) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#784](https://github.com/Shopify/brooklyn/pull/784) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#782](https://github.com/Shopify/brooklyn/pull/782) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#780](https://github.com/Shopify/brooklyn/pull/780) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#781](https://github.com/Shopify/brooklyn/pull/781) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v15.2.5 (2020-02-04)

#### 🌏 Translation
* [#778](https://github.com/Shopify/brooklyn/pull/778) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#779](https://github.com/Shopify/brooklyn/pull/779) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#774](https://github.com/Shopify/brooklyn/pull/774) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#772](https://github.com/Shopify/brooklyn/pull/772) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### 🏠 Internal
* [#771](https://github.com/Shopify/brooklyn/pull/771) add issue templates ([@ALamm](https://github.com/ALamm))

#### Committers: 2
- Alexander Lamm ([@ALamm](https://github.com/ALamm))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v15.2.4 (2020-01-28)

#### 🐜 Bug fix
* [#759](https://github.com/Shopify/brooklyn/pull/759) Show unit price even when variant is not available ([@adjnor](https://github.com/adjnor))

#### 🌏 Translation
* [#763](https://github.com/Shopify/brooklyn/pull/763) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#762](https://github.com/Shopify/brooklyn/pull/762) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#761](https://github.com/Shopify/brooklyn/pull/761) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### 🏠 Internal
* [#764](https://github.com/Shopify/brooklyn/pull/764) Bump st-release to 2.1.3 ([@tauthomas01](https://github.com/tauthomas01))
* [#760](https://github.com/Shopify/brooklyn/pull/760) chore: version bump v15.2.3 ([@martinamarien](https://github.com/martinamarien))

#### Committers: 4
- Jordan Rooks ([@adjnor](https://github.com/adjnor))
- Martina Marien ([@martinamarien](https://github.com/martinamarien))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- [@tauthomas01](https://github.com/tauthomas01)

## v15.2.3 (2020-01-22)

#### 🌏 Translation
* [#756](https://github.com/Shopify/brooklyn/pull/756) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#755](https://github.com/Shopify/brooklyn/pull/755) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#754](https://github.com/Shopify/brooklyn/pull/754) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#752](https://github.com/Shopify/brooklyn/pull/752) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v15.2.2 (2020-01-16)

#### 🌏 Translation
* [#742](https://github.com/Shopify/brooklyn/pull/742) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#745](https://github.com/Shopify/brooklyn/pull/745) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#741](https://github.com/Shopify/brooklyn/pull/741) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#734](https://github.com/Shopify/brooklyn/pull/734) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v15.2.1 (2020-01-07)

#### 🐜 Bug fix
* [#726](https://github.com/Shopify/brooklyn/pull/726) Fix product background color for transparent products ([@tauthomas01](https://github.com/tauthomas01))
* [#722](https://github.com/Shopify/brooklyn/pull/722) Use translated strings for name attribute of contact page fields ([@KaichenWang](https://github.com/KaichenWang))

#### 🌏 Translation
* [#732](https://github.com/Shopify/brooklyn/pull/732) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#731](https://github.com/Shopify/brooklyn/pull/731) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#730](https://github.com/Shopify/brooklyn/pull/730) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#729](https://github.com/Shopify/brooklyn/pull/729) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#728](https://github.com/Shopify/brooklyn/pull/728) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#727](https://github.com/Shopify/brooklyn/pull/727) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#725](https://github.com/Shopify/brooklyn/pull/725) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#723](https://github.com/Shopify/brooklyn/pull/723) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 3
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- Thomas Tau ([@tauthomas01](https://github.com/tauthomas01))
- [@KaichenWang](https://github.com/KaichenWang)

## v15.2.0 (2019-12-11)

#### 🚀 Enhancement
* [#700](https://github.com/Shopify/brooklyn/pull/700) Fix header colors ([@tauthomas01](https://github.com/tauthomas01))

#### 🐜 Bug fix
* [#719](https://github.com/Shopify/brooklyn/pull/719) Fix forgot password message ([@tauthomas01](https://github.com/tauthomas01))

#### 🌏 Translation
* [#720](https://github.com/Shopify/brooklyn/pull/720) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#718](https://github.com/Shopify/brooklyn/pull/718) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#717](https://github.com/Shopify/brooklyn/pull/717) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#716](https://github.com/Shopify/brooklyn/pull/716) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#712](https://github.com/Shopify/brooklyn/pull/712) [SAR China] Country/Region ([@larouxn](https://github.com/larouxn))
* [#707](https://github.com/Shopify/brooklyn/pull/707) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#710](https://github.com/Shopify/brooklyn/pull/710) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### 🏠 Internal
* [#714](https://github.com/Shopify/brooklyn/pull/714) remove ruby dep ([@NathanPJF](https://github.com/NathanPJF))

#### Committers: 4
- Nathan Ferguson ([@NathanPJF](https://github.com/NathanPJF))
- Nicholas La Roux ([@larouxn](https://github.com/larouxn))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- Thomas Tau ([@tauthomas01](https://github.com/tauthomas01))

## v15.1.0 (2019-11-19)

#### 🚀 Enhancement
* [#694](https://github.com/Shopify/brooklyn/pull/694) Fetch product recommendations from locale specific url ([@cbothner](https://github.com/cbothner))

#### 🌏 Translation
* [#706](https://github.com/Shopify/brooklyn/pull/706) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#705](https://github.com/Shopify/brooklyn/pull/705) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#703](https://github.com/Shopify/brooklyn/pull/703) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#702](https://github.com/Shopify/brooklyn/pull/702) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#699](https://github.com/Shopify/brooklyn/pull/699) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#701](https://github.com/Shopify/brooklyn/pull/701) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 2
- Cameron Bothner ([@cbothner](https://github.com/cbothner))
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v15.0.0 (2019-11-06)

#### 💥 Breaking Change
* [#627](https://github.com/Shopify/brooklyn/pull/627) Make the slideshow "re-arrangeable" ([@tauthomas01](https://github.com/tauthomas01))

#### 🌏 Translation
* [#698](https://github.com/Shopify/brooklyn/pull/698) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#697](https://github.com/Shopify/brooklyn/pull/697) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#696](https://github.com/Shopify/brooklyn/pull/696) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#695](https://github.com/Shopify/brooklyn/pull/695) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#693](https://github.com/Shopify/brooklyn/pull/693) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 2
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))
- Thomas Tau ([@tauthomas01](https://github.com/tauthomas01))

## v14.1.5 (2019-10-30)

#### 🌏 Translation
* [#691](https://github.com/Shopify/brooklyn/pull/691) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#692](https://github.com/Shopify/brooklyn/pull/692) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#690](https://github.com/Shopify/brooklyn/pull/690) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#689](https://github.com/Shopify/brooklyn/pull/689) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#688](https://github.com/Shopify/brooklyn/pull/688) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#687](https://github.com/Shopify/brooklyn/pull/687) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#686](https://github.com/Shopify/brooklyn/pull/686) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v14.1.4 (2019-10-21)

#### 🌏 Translation
* [#682](https://github.com/Shopify/brooklyn/pull/682) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#681](https://github.com/Shopify/brooklyn/pull/681) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#680](https://github.com/Shopify/brooklyn/pull/680) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#678](https://github.com/Shopify/brooklyn/pull/678) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#677](https://github.com/Shopify/brooklyn/pull/677) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v14.1.3 (2019-10-15)

#### 🌏 Translation
* [#676](https://github.com/Shopify/brooklyn/pull/676) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#674](https://github.com/Shopify/brooklyn/pull/674) Update translations: merchant ([@translation-platform](https://github.com/translation-platform))
* [#675](https://github.com/Shopify/brooklyn/pull/675) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))
* [#673](https://github.com/Shopify/brooklyn/pull/673) Update translations: buyer ([@translation-platform](https://github.com/translation-platform))

#### Committers: 1
- Shopify Translation Platform ([@translation-platform](https://github.com/translation-platform))

## v14.1.2 (2019-10-08)

#### 🐜 Bug fix
* [#664](https://github.com/Shopify/brooklyn/pull/664) Fix vendor / type collection filters ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))

#### 🏠 Internal
* [#669](https://github.com/Shopify/brooklyn/pull/669) use new st-release tool, include translations in Changelogs ([@NathanPJF](https://github.com/NathanPJF))

#### Committers: 2
- Lucas Lacerda ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))
- Nathan Ferguson ([@NathanPJF](https://github.com/NathanPJF))

## v14.1.1 (2019-10-01)

#### 🏠 Internal
* [#656](https://github.com/Shopify/brooklyn/pull/656) Add tooling for Sections Everywhere ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))

#### Committers: 1
- Lucas Lacerda ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))

## v14.1.0 (2019-09-25)

#### 🚀 Enhancement
* [#653](https://github.com/Shopify/brooklyn/pull/653) Replace template with request object ([@chrisberthe](https://github.com/chrisberthe))

#### Committers: 1
- Chris Berthe ([@chrisberthe](https://github.com/chrisberthe))

## v14.0.0 (2019-09-19)

#### 💥 Breaking Change
* [#648](https://github.com/Shopify/brooklyn/pull/648) Merge collection templates ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))

#### 🐜 Bug fix
* [#650](https://github.com/Shopify/brooklyn/pull/650) Fixes collection image container size ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))
* [#651](https://github.com/Shopify/brooklyn/pull/651) Fix slideshow height on Theme Editor in Safari mobile ([@tauthomas01](https://github.com/tauthomas01))

#### 🏠 Internal
* [#654](https://github.com/Shopify/brooklyn/pull/654) Remove Visual Testing ([@chrisberthe](https://github.com/chrisberthe))

#### Committers: 3
- Chris Berthe ([@chrisberthe](https://github.com/chrisberthe))
- Lucas Lacerda ([@LucasLacerdaUX](https://github.com/LucasLacerdaUX))
- Thomas Tau ([@tauthomas01](https://github.com/tauthomas01))

## v13.2.0 (2019-09-11)

#### 🚀 Enhancement
* [#646](https://github.com/Shopify/brooklyn/pull/646) [MultiCurrency] Code logic to use cart currency ([@tjoyal](https://github.com/tjoyal))

#### Committers: 1
- Thierry Joyal ([@tjoyal](https://github.com/tjoyal))

## v13.1.4 (2019-09-04)

#### 🐜 Bug fix
* [#634](https://github.com/Shopify/brooklyn/pull/634) Hide unit price in collection when price varies ([@adjnor](https://github.com/adjnor))

#### 🏠 Internal
* [#645](https://github.com/Shopify/brooklyn/pull/645) bump st-release version ([@martinamarien](https://github.com/martinamarien))

#### Committers: 2
- Jordan Rooks ([@adjnor](https://github.com/adjnor))
- Martina Marien ([@martinamarien](https://github.com/martinamarien))

## v13.1.3 (2019-08-28)

#### 🐜 Bug fix
* [#637](https://github.com/Shopify/brooklyn/pull/637) Fix product variant name conflicts ([@tauthomas01](https://github.com/tauthomas01))

#### Committers: 1
- [@tauthomas01](https://github.com/tauthomas01)

## v13.1.2 (2019-08-23)

#### 🐜 Bug fix
* [#616](https://github.com/Shopify/brooklyn/pull/616) fix: adds focus to search modal input ([@bczegeny](https://github.com/bczegeny))

#### 🚀 Enhancement
* [#631](https://github.com/Shopify/brooklyn/pull/631) Remove product recommendations Trekkie event method ([@chrisberthe](https://github.com/chrisberthe))

#### 🏠 Internal
* [#636](https://github.com/Shopify/brooklyn/pull/636) add @shopify/st-release ([@NathanPJF](https://github.com/NathanPJF))
* [#620](https://github.com/Shopify/brooklyn/pull/620) Update dev.yml to use Yarn instead of NPM ([@chrisberthe](https://github.com/chrisberthe))

#### Committers: 3
- Benjamin Czegeny ([@bczegeny](https://github.com/bczegeny))
- Chris Berthe ([@chrisberthe](https://github.com/chrisberthe))
- Nathan Ferguson ([@NathanPJF](https://github.com/NathanPJF))

## [v13.1.1](https://github.com/Shopify/brooklyn/tree/HEAD)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v13.1.0...HEAD)

**Merged pull requests:**

- Add translations: buyer [\#611](https://github.com/Shopify/brooklyn/pull/611) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#610](https://github.com/Shopify/brooklyn/pull/610) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#609](https://github.com/Shopify/brooklyn/pull/609) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#608](https://github.com/Shopify/brooklyn/pull/608) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#607](https://github.com/Shopify/brooklyn/pull/607) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#606](https://github.com/Shopify/brooklyn/pull/606) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#603](https://github.com/Shopify/brooklyn/pull/603) ([translation-platform](https://github.com/translation-platform))

## [v13.1.0](https://github.com/Shopify/brooklyn/tree/v13.1.0) (2019-07-16)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v13.0.0...v13.1.0)

**Closed issues:**

- Search on Sidebar/drawer controlled by non-existent setting [\#525](https://github.com/Shopify/brooklyn/issues/525)

**Merged pull requests:**

- add dev.yml file [\#604](https://github.com/Shopify/brooklyn/pull/604) ([NathanPJF](https://github.com/NathanPJF))
- Add translations: merchant [\#602](https://github.com/Shopify/brooklyn/pull/602) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#601](https://github.com/Shopify/brooklyn/pull/601) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#600](https://github.com/Shopify/brooklyn/pull/600) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#599](https://github.com/Shopify/brooklyn/pull/599) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#597](https://github.com/Shopify/brooklyn/pull/597) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#596](https://github.com/Shopify/brooklyn/pull/596) ([translation-platform](https://github.com/translation-platform))
- Remove hardcoded links from liquid and JS [\#594](https://github.com/Shopify/brooklyn/pull/594) ([martinamarien](https://github.com/martinamarien))
- Add translations: merchant [\#592](https://github.com/Shopify/brooklyn/pull/592) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#591](https://github.com/Shopify/brooklyn/pull/591) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#590](https://github.com/Shopify/brooklyn/pull/590) ([translation-platform](https://github.com/translation-platform))
- Translations for the Unite 2019 languages [\#589](https://github.com/Shopify/brooklyn/pull/589) ([NathanPJF](https://github.com/NathanPJF))
- Add translations: buyer [\#587](https://github.com/Shopify/brooklyn/pull/587) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#586](https://github.com/Shopify/brooklyn/pull/586) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#585](https://github.com/Shopify/brooklyn/pull/585) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#584](https://github.com/Shopify/brooklyn/pull/584) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#583](https://github.com/Shopify/brooklyn/pull/583) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#582](https://github.com/Shopify/brooklyn/pull/582) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#581](https://github.com/Shopify/brooklyn/pull/581) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#579](https://github.com/Shopify/brooklyn/pull/579) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#578](https://github.com/Shopify/brooklyn/pull/578) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#577](https://github.com/Shopify/brooklyn/pull/577) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#576](https://github.com/Shopify/brooklyn/pull/576) ([translation-platform](https://github.com/translation-platform))
- \[Unit Price\] Update unit price on variant selection [\#575](https://github.com/Shopify/brooklyn/pull/575) ([tauthomas01](https://github.com/tauthomas01))
- Add translations: buyer [\#573](https://github.com/Shopify/brooklyn/pull/573) ([translation-platform](https://github.com/translation-platform))
- \[Unit Price\] Add feature to Brooklyn [\#571](https://github.com/Shopify/brooklyn/pull/571) ([tauthomas01](https://github.com/tauthomas01))
- Add translations: buyer [\#570](https://github.com/Shopify/brooklyn/pull/570) ([translation-platform](https://github.com/translation-platform))
- chore: version bump v13.0.0 [\#569](https://github.com/Shopify/brooklyn/pull/569) ([rickitan](https://github.com/rickitan))

## [v13.0.0](https://github.com/Shopify/brooklyn/tree/v13.0.0) (2019-06-10)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v12.2.0...v13.0.0)

**Merged pull requests:**

- enable product recommendations by default [\#568](https://github.com/Shopify/brooklyn/pull/568) ([rickitan](https://github.com/rickitan))
- chore: version bump v12.2.0 [\#567](https://github.com/Shopify/brooklyn/pull/567) ([rickitan](https://github.com/rickitan))
- fix: adjust timeout - bump test verson [\#561](https://github.com/Shopify/brooklyn/pull/561) ([bczegeny](https://github.com/bczegeny))

## [v12.2.0](https://github.com/Shopify/brooklyn/tree/v12.2.0) (2019-06-10)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v12.1.3...v12.2.0)

**Merged pull requests:**

- Add translations: buyer [\#564](https://github.com/Shopify/brooklyn/pull/564) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#563](https://github.com/Shopify/brooklyn/pull/563) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#562](https://github.com/Shopify/brooklyn/pull/562) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#560](https://github.com/Shopify/brooklyn/pull/560) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#558](https://github.com/Shopify/brooklyn/pull/558) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#557](https://github.com/Shopify/brooklyn/pull/557) ([translation-platform](https://github.com/translation-platform))
- update testing package and scripts [\#556](https://github.com/Shopify/brooklyn/pull/556) ([jeremystephencobb](https://github.com/jeremystephencobb))
- adds product recos section to product pages [\#543](https://github.com/Shopify/brooklyn/pull/543) ([rickitan](https://github.com/rickitan))
- Adds loading placeholder to product-grid-item.liquid [\#541](https://github.com/Shopify/brooklyn/pull/541) ([rickitan](https://github.com/rickitan))
- Update configuration languages in translations.yml [\#499](https://github.com/Shopify/brooklyn/pull/499) ([translation-platform](https://github.com/translation-platform))

## [v12.1.3](https://github.com/Shopify/brooklyn/tree/v12.1.3) (2019-05-27)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v12.1.2...v12.1.3)

**Merged pull requests:**

- Add translations: merchant [\#555](https://github.com/Shopify/brooklyn/pull/555) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#554](https://github.com/Shopify/brooklyn/pull/554) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#553](https://github.com/Shopify/brooklyn/pull/553) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#552](https://github.com/Shopify/brooklyn/pull/552) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#551](https://github.com/Shopify/brooklyn/pull/551) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#550](https://github.com/Shopify/brooklyn/pull/550) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#549](https://github.com/Shopify/brooklyn/pull/549) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#548](https://github.com/Shopify/brooklyn/pull/548) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#547](https://github.com/Shopify/brooklyn/pull/547) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#546](https://github.com/Shopify/brooklyn/pull/546) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#545](https://github.com/Shopify/brooklyn/pull/545) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#544](https://github.com/Shopify/brooklyn/pull/544) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#542](https://github.com/Shopify/brooklyn/pull/542) ([translation-platform](https://github.com/translation-platform))
- Add rel="nofollow" on shopify.com link [\#540](https://github.com/Shopify/brooklyn/pull/540) ([one20](https://github.com/one20))

## [v12.1.2](https://github.com/Shopify/brooklyn/tree/v12.1.2) (2019-05-15)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v12.1.1...v12.1.2)

**Merged pull requests:**

- Modified i18n date formats away from custom formats [\#539](https://github.com/Shopify/brooklyn/pull/539) ([bimalbhagrath](https://github.com/bimalbhagrath))
- Add translations: merchant [\#538](https://github.com/Shopify/brooklyn/pull/538) ([translation-platform](https://github.com/translation-platform))
- use correct variable for order subtotal [\#537](https://github.com/Shopify/brooklyn/pull/537) ([huguestennier](https://github.com/huguestennier))

## [v12.1.1](https://github.com/Shopify/brooklyn/tree/v12.1.1) (2019-05-01)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v12.1.0...v12.1.1)

**Closed issues:**

- Brooklyn v12+ - Slideshow gets 'stuck' after being hovered on \(doesn't unpause\) [\#493](https://github.com/Shopify/brooklyn/issues/493)
- \[Slideshow\] IE 11 Controls not centered [\#475](https://github.com/Shopify/brooklyn/issues/475)

**Merged pull requests:**

- Fix AJAX Cart HTML rendering for discounts [\#536](https://github.com/Shopify/brooklyn/pull/536) ([huguestennier](https://github.com/huguestennier))
- \[Predictive Search\] Update icon font and fix X usage [\#534](https://github.com/Shopify/brooklyn/pull/534) ([beefchimi](https://github.com/beefchimi))
- \[Predictive Search\] Implement styling for results [\#533](https://github.com/Shopify/brooklyn/pull/533) ([beefchimi](https://github.com/beefchimi))
- \[Predictive Search\] Search Header Drawer Skeleton [\#531](https://github.com/Shopify/brooklyn/pull/531) ([beefchimi](https://github.com/beefchimi))
- Update pipelines [\#529](https://github.com/Shopify/brooklyn/pull/529) ([chrisberthe](https://github.com/chrisberthe))
- \[Predictive Search\] Mobile Nav Skeleton [\#528](https://github.com/Shopify/brooklyn/pull/528) ([beefchimi](https://github.com/beefchimi))
- \[Predictive Search\] Style mobile-nav search input [\#527](https://github.com/Shopify/brooklyn/pull/527) ([beefchimi](https://github.com/beefchimi))
- Add translations: buyer [\#524](https://github.com/Shopify/brooklyn/pull/524) ([translation-platform](https://github.com/translation-platform))
- Fix ie11 slideshow control position [\#523](https://github.com/Shopify/brooklyn/pull/523) ([ruairiphackett](https://github.com/ruairiphackett))
- Add mouse enter/leave event listeners to slideshow [\#522](https://github.com/Shopify/brooklyn/pull/522) ([ruairiphackett](https://github.com/ruairiphackett))

## [v12.1.0](https://github.com/Shopify/brooklyn/tree/v12.1.0) (2019-04-22)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v12.0.5...v12.1.0)

**Merged pull requests:**

- Add translations: buyer [\#521](https://github.com/Shopify/brooklyn/pull/521) ([translation-platform](https://github.com/translation-platform))
- Add new discount logic [\#428](https://github.com/Shopify/brooklyn/pull/428) ([huguestennier](https://github.com/huguestennier))

## [v12.0.5](https://github.com/Shopify/brooklyn/tree/v12.0.5) (2019-04-17)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v12.0.4...v12.0.5)

**Merged pull requests:**

- Add translations: merchant [\#520](https://github.com/Shopify/brooklyn/pull/520) ([translation-platform](https://github.com/translation-platform))
- chore: bump testing package version [\#517](https://github.com/Shopify/brooklyn/pull/517) ([jeremystephencobb](https://github.com/jeremystephencobb))
- Add translations: buyer [\#515](https://github.com/Shopify/brooklyn/pull/515) ([translation-platform](https://github.com/translation-platform))
- use online-store-editor scheme [\#514](https://github.com/Shopify/brooklyn/pull/514) ([NathanPJF](https://github.com/NathanPJF))
- Add translations: merchant [\#513](https://github.com/Shopify/brooklyn/pull/513) ([translation-platform](https://github.com/translation-platform))
- Add cart template discount [\#496](https://github.com/Shopify/brooklyn/pull/496) ([huguestennier](https://github.com/huguestennier))

## [v12.0.4](https://github.com/Shopify/brooklyn/tree/v12.0.4) (2019-04-02)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v12.0.3...v12.0.4)

**Closed issues:**

- a11y issue with slideshow dots/arrows using keyboard [\#510](https://github.com/Shopify/brooklyn/issues/510)
- Can't deploy to different environments [\#505](https://github.com/Shopify/brooklyn/issues/505)

**Merged pull requests:**

- Fix Liquid exception in product template [\#512](https://github.com/Shopify/brooklyn/pull/512) ([chrisberthe](https://github.com/chrisberthe))
- fix: a11y update keyboard arrows on dots [\#511](https://github.com/Shopify/brooklyn/pull/511) ([matcaissy](https://github.com/matcaissy))
- Add translations: buyer [\#509](https://github.com/Shopify/brooklyn/pull/509) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#508](https://github.com/Shopify/brooklyn/pull/508) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#507](https://github.com/Shopify/brooklyn/pull/507) ([translation-platform](https://github.com/translation-platform))
- fix deploy to environments [\#506](https://github.com/Shopify/brooklyn/pull/506) ([NathanPJF](https://github.com/NathanPJF))
- chore: update pipeline image [\#502](https://github.com/Shopify/brooklyn/pull/502) ([bczegeny](https://github.com/bczegeny))
- Add translations: merchant [\#489](https://github.com/Shopify/brooklyn/pull/489) ([translation-platform](https://github.com/translation-platform))

## [v12.0.3](https://github.com/Shopify/brooklyn/tree/v12.0.3) (2019-03-26)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v12.0.2...v12.0.3)

**Closed issues:**

- No apple-touch-icon declaration so favourites in Safari don't show merchant branding [\#491](https://github.com/Shopify/brooklyn/issues/491)
- Header flashing due to JS [\#209](https://github.com/Shopify/brooklyn/issues/209)

**Merged pull requests:**

- Add translations: buyer [\#504](https://github.com/Shopify/brooklyn/pull/504) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#503](https://github.com/Shopify/brooklyn/pull/503) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#501](https://github.com/Shopify/brooklyn/pull/501) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#500](https://github.com/Shopify/brooklyn/pull/500) ([translation-platform](https://github.com/translation-platform))
- Add AJAX Cart discounts [\#498](https://github.com/Shopify/brooklyn/pull/498) ([huguestennier](https://github.com/huguestennier))
- Add translations: buyer [\#495](https://github.com/Shopify/brooklyn/pull/495) ([translation-platform](https://github.com/translation-platform))
- Updating Translations CI [\#492](https://github.com/Shopify/brooklyn/pull/492) ([harshal317](https://github.com/harshal317))
- chore: bump testing version [\#490](https://github.com/Shopify/brooklyn/pull/490) ([jeremystephencobb](https://github.com/jeremystephencobb))
- Updating to Node LTS [\#488](https://github.com/Shopify/brooklyn/pull/488) ([harshal317](https://github.com/harshal317))
- Update configuration languages in translations.yml [\#479](https://github.com/Shopify/brooklyn/pull/479) ([translation-platform](https://github.com/translation-platform))

## [v12.0.2](https://github.com/Shopify/brooklyn/tree/v12.0.2) (2019-03-05)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v12.0.1...v12.0.2)

**Closed issues:**

- Incorrect markdown in merchant facing links in slideshow section [\#477](https://github.com/Shopify/brooklyn/issues/477)
- \[Discussion\] Improve slideshow and header loading states [\#144](https://github.com/Shopify/brooklyn/issues/144)

**Merged pull requests:**

- chore: bump testing [\#487](https://github.com/Shopify/brooklyn/pull/487) ([bczegeny](https://github.com/bczegeny))
- Add translations: buyer [\#486](https://github.com/Shopify/brooklyn/pull/486) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#485](https://github.com/Shopify/brooklyn/pull/485) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#483](https://github.com/Shopify/brooklyn/pull/483) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#482](https://github.com/Shopify/brooklyn/pull/482) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#481](https://github.com/Shopify/brooklyn/pull/481) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#480](https://github.com/Shopify/brooklyn/pull/480) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#478](https://github.com/Shopify/brooklyn/pull/478) ([translation-platform](https://github.com/translation-platform))

## [v12.0.1](https://github.com/Shopify/brooklyn/tree/v12.0.1) (2019-02-04)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v12.0.0...v12.0.1)

**Closed issues:**

- Brooklyn Cart Drawer Resulting in Bad Request When Variant Option is called Elements [\#228](https://github.com/Shopify/brooklyn/issues/228)

**Merged pull requests:**

- Add translations: merchant [\#473](https://github.com/Shopify/brooklyn/pull/473) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#472](https://github.com/Shopify/brooklyn/pull/472) ([translation-platform](https://github.com/translation-platform))
- fix: update test data schema [\#471](https://github.com/Shopify/brooklyn/pull/471) ([jeremystephencobb](https://github.com/jeremystephencobb))
- Using new collection sort options [\#470](https://github.com/Shopify/brooklyn/pull/470) ([harshal317](https://github.com/harshal317))
- Fixes Add to Cart for products with variant option called Elements [\#467](https://github.com/Shopify/brooklyn/pull/467) ([harshal317](https://github.com/harshal317))

## [v12.0.0](https://github.com/Shopify/brooklyn/tree/v12.0.0) (2019-01-23)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v11.0.3...v12.0.0)

**Closed issues:**

- \[Theme Parity\] Slideshow section [\#187](https://github.com/Shopify/brooklyn/issues/187)

**Merged pull requests:**

- chore: adding testing files [\#432](https://github.com/Shopify/brooklyn/pull/432) ([bczegeny](https://github.com/bczegeny))
- Add new Slideshow \[rebase\] [\#427](https://github.com/Shopify/brooklyn/pull/427) ([ruairiphackett](https://github.com/ruairiphackett))

## [v11.0.3](https://github.com/Shopify/brooklyn/tree/v11.0.3) (2019-01-22)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v11.0.2...v11.0.3)

**Merged pull requests:**

- Add translations: merchant [\#469](https://github.com/Shopify/brooklyn/pull/469) ([translation-platform](https://github.com/translation-platform))

## [v11.0.2](https://github.com/Shopify/brooklyn/tree/v11.0.2) (2019-01-07)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v11.0.1...v11.0.2)

**Merged pull requests:**

- Add translations: buyer [\#459](https://github.com/Shopify/brooklyn/pull/459) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#458](https://github.com/Shopify/brooklyn/pull/458) ([translation-platform](https://github.com/translation-platform))

## [v11.0.1](https://github.com/Shopify/brooklyn/tree/v11.0.1) (2018-12-11)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v11.0.0...v11.0.1)

**Merged pull requests:**

- Add translations: buyer [\#430](https://github.com/Shopify/brooklyn/pull/430) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#429](https://github.com/Shopify/brooklyn/pull/429) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#426](https://github.com/Shopify/brooklyn/pull/426) ([translation-platform](https://github.com/translation-platform))
- Add translations: merchant [\#425](https://github.com/Shopify/brooklyn/pull/425) ([translation-platform](https://github.com/translation-platform))

## [v11.0.0](https://github.com/Shopify/brooklyn/tree/v11.0.0) (2018-11-29)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v10.2.4...v11.0.0)

**Merged pull requests:**

- feat: turn on dynamic checkout button on default [\#423](https://github.com/Shopify/brooklyn/pull/423) ([matcaissy](https://github.com/matcaissy))

## [v10.2.4](https://github.com/Shopify/brooklyn/tree/v10.2.4) (2018-11-28)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v10.2.3...v10.2.4)

**Merged pull requests:**

- fix: Revert password layout lang [\#424](https://github.com/Shopify/brooklyn/pull/424) ([ruairiphackett](https://github.com/ruairiphackett))

## [v10.2.3](https://github.com/Shopify/brooklyn/tree/v10.2.3) (2018-11-28)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v10.2.2...v10.2.3)

**Merged pull requests:**

- Add translations: buyer [\#412](https://github.com/Shopify/brooklyn/pull/412) ([translation-platform](https://github.com/translation-platform))
- chore: remove old ie code [\#359](https://github.com/Shopify/brooklyn/pull/359) ([jeremystephencobb](https://github.com/jeremystephencobb))

## [v10.2.2](https://github.com/Shopify/brooklyn/tree/v10.2.2) (2018-11-19)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v10.2.1...v10.2.2)

**Closed issues:**

- \[Global\] Placeholder text has insufficient color contrast [\#290](https://github.com/Shopify/brooklyn/issues/290)

**Merged pull requests:**

- add \<html\> lang attribute [\#411](https://github.com/Shopify/brooklyn/pull/411) ([NathanPJF](https://github.com/NathanPJF))
- Add translations: buyer [\#410](https://github.com/Shopify/brooklyn/pull/410) ([translation-platform](https://github.com/translation-platform))
- use proper variable [\#407](https://github.com/Shopify/brooklyn/pull/407) ([NathanPJF](https://github.com/NathanPJF))
- Add translations: buyer [\#377](https://github.com/Shopify/brooklyn/pull/377) ([translation-platform](https://github.com/translation-platform))

## [v10.2.1](https://github.com/Shopify/brooklyn/tree/v10.2.1) (2018-10-24)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v10.2.0...v10.2.1)

**Closed issues:**

- Missing classification [\#362](https://github.com/Shopify/brooklyn/issues/362)
- Last element in cart form does not receive border-top in theme editor [\#355](https://github.com/Shopify/brooklyn/issues/355)

**Merged pull requests:**

- Add a service.yml file \(Services DB manifest\) [\#363](https://github.com/Shopify/brooklyn/pull/363) ([shopify-services](https://github.com/shopify-services))
- Add translations: merchant [\#361](https://github.com/Shopify/brooklyn/pull/361) ([translation-platform](https://github.com/translation-platform))
- Fix missing top border in theme editor for cart page [\#360](https://github.com/Shopify/brooklyn/pull/360) ([wizardlyhel](https://github.com/wizardlyhel))
- Rename Shopify Build Env Vars [\#358](https://github.com/Shopify/brooklyn/pull/358) ([JackTLi](https://github.com/JackTLi))
- Add translations: buyer [\#356](https://github.com/Shopify/brooklyn/pull/356) ([translation-platform](https://github.com/translation-platform))

## [v10.2.0](https://github.com/Shopify/brooklyn/tree/v10.2.0) (2018-10-04)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v10.1.0...v10.2.0)

**Merged pull requests:**

- German VAT compliance [\#307](https://github.com/Shopify/brooklyn/pull/307) ([martinamarien](https://github.com/martinamarien))

## [v10.1.0](https://github.com/Shopify/brooklyn/tree/v10.1.0) (2018-09-18)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v10.0.3...v10.1.0)

**Closed issues:**

- Featured Product typo in image src - causing issues with ad blockers. [\#259](https://github.com/Shopify/brooklyn/issues/259)

**Merged pull requests:**

- fix: update format_address on orders page [\#327](https://github.com/Shopify/brooklyn/pull/327) ([matcaissy](https://github.com/matcaissy))
- Add translations: buyer [\#326](https://github.com/Shopify/brooklyn/pull/326) ([translation-platform](https://github.com/translation-platform))
- Add translations: buyer [\#295](https://github.com/Shopify/brooklyn/pull/295) ([translation-platform](https://github.com/translation-platform))
- Add workspace settings [\#261](https://github.com/Shopify/brooklyn/pull/261) ([chrisberthe](https://github.com/chrisberthe))
- fix: Typo in featured product image src [\#260](https://github.com/Shopify/brooklyn/pull/260) ([ruairiphackett](https://github.com/ruairiphackett))

## [v10.0.3](https://github.com/Shopify/brooklyn/tree/v10.0.3) (2018-08-30)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v10.0.2...v10.0.3)

**Closed issues:**

- Issues with new menu drawer [\#256](https://github.com/Shopify/brooklyn/issues/256)
- Mobile Menu not scrolling in V 10.0.0 and up [\#249](https://github.com/Shopify/brooklyn/issues/249)

**Merged pull requests:**

- fix: add conditional for prevent default [\#258](https://github.com/Shopify/brooklyn/pull/258) ([jeremystephencobb](https://github.com/jeremystephencobb))
- fix: re-order menu structure [\#257](https://github.com/Shopify/brooklyn/pull/257) ([matcaissy](https://github.com/matcaissy))
- Add deploy-overwrite task [\#248](https://github.com/Shopify/brooklyn/pull/248) ([chrisberthe](https://github.com/chrisberthe))
- Add translations: buyer [\#246](https://github.com/Shopify/brooklyn/pull/246) ([translation-platform](https://github.com/translation-platform))
- Add initial configuration for translation platform [\#240](https://github.com/Shopify/brooklyn/pull/240) ([translation-platform](https://github.com/translation-platform))

## [v10.0.2](https://github.com/Shopify/brooklyn/tree/v10.0.2) (2018-08-21)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v10.0.1...v10.0.2)

**Merged pull requests:**

- fix: cart drawer updates [\#245](https://github.com/Shopify/brooklyn/pull/245) ([jeremystephencobb](https://github.com/jeremystephencobb))
- Update structure for translation platform [\#241](https://github.com/Shopify/brooklyn/pull/241) ([chrisberthe](https://github.com/chrisberthe))

## [v10.0.1](https://github.com/Shopify/brooklyn/tree/v10.0.1) (2018-08-21)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v10.0.0...v10.0.1)

**Closed issues:**

- Check Out button not visible in Drawer mode in v10.0.0 [\#243](https://github.com/Shopify/brooklyn/issues/243)
- Buy now button missing on featured products after first [\#242](https://github.com/Shopify/brooklyn/issues/242)

**Merged pull requests:**

- fix: fix hidden checkout button [\#244](https://github.com/Shopify/brooklyn/pull/244) ([jeremystephencobb](https://github.com/jeremystephencobb))

## [v10.0.0](https://github.com/Shopify/brooklyn/tree/v10.0.0) (2018-08-20)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v9.1.0...v10.0.0)

**Closed issues:**

- Ability to set primary menu in sidebar is potentially misleading [\#185](https://github.com/Shopify/brooklyn/issues/185)

**Merged pull requests:**

- Update button colors [\#239](https://github.com/Shopify/brooklyn/pull/239) ([melissaperreault](https://github.com/melissaperreault))
- Remove sidebar section [\#227](https://github.com/Shopify/brooklyn/pull/227) ([jeremystephencobb](https://github.com/jeremystephencobb))

## [v9.1.0](https://github.com/Shopify/brooklyn/tree/v9.1.0) (2018-08-01)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v9.0.1...v9.1.0)

**Closed issues:**

- Longer Cart Drawer Titles fail to push cart items down [\#232](https://github.com/Shopify/brooklyn/issues/232)
- Vendor shows on collection view but not featured collection view. [\#75](https://github.com/Shopify/brooklyn/issues/75)

**Merged pull requests:**

- i18n: Apply wording changes received from translators for pt-BR [\#238](https://github.com/Shopify/brooklyn/pull/238) ([cejaekl](https://github.com/cejaekl))
- i18n: Adds translations of config/settings_schema.json [\#237](https://github.com/Shopify/brooklyn/pull/237) ([cejaekl](https://github.com/cejaekl))
- Minor corrections to translations for ja, it, es. [\#235](https://github.com/Shopify/brooklyn/pull/235) ([cejaekl](https://github.com/cejaekl))
- fix: long cart drawer titles break cart on small screens [\#234](https://github.com/Shopify/brooklyn/pull/234) ([jeremystephencobb](https://github.com/jeremystephencobb))
- Change `de` translation from "Speichern" to "Sie sparen" [\#233](https://github.com/Shopify/brooklyn/pull/233) ([cejaekl](https://github.com/cejaekl))

## [v9.0.1](https://github.com/Shopify/brooklyn/tree/v9.0.1) (2018-07-11)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v9.0.0...v9.0.1)

**Merged pull requests:**

- Add section translations to \(de, es, fr, it, ja and pt-BR\). [\#231](https://github.com/Shopify/brooklyn/pull/231) ([cejaekl](https://github.com/cejaekl))

## [v9.0.0](https://github.com/Shopify/brooklyn/tree/v9.0.0) (2018-06-28)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v8.0.1...v9.0.0)

**Merged pull requests:**

- feat: new payment icons [\#229](https://github.com/Shopify/brooklyn/pull/229) ([jeremystephencobb](https://github.com/jeremystephencobb))

## [v8.0.1](https://github.com/Shopify/brooklyn/tree/v8.0.1) (2018-06-13)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v8.0.0...v8.0.1)

**Closed issues:**

- Search results page [\#215](https://github.com/Shopify/brooklyn/issues/215)

**Merged pull requests:**

- Search image alignment [\#223](https://github.com/Shopify/brooklyn/pull/223) ([jeremystephencobb](https://github.com/jeremystephencobb))

## [v8.0.0](https://github.com/Shopify/brooklyn/tree/v8.0.0) (2018-05-29)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v7.0.1...v8.0.0)

**Merged pull requests:**

- breaking change: add new font picker [\#212](https://github.com/Shopify/brooklyn/pull/212) ([matcaissy](https://github.com/matcaissy))

## [v7.0.1](https://github.com/Shopify/brooklyn/tree/v7.0.1) (2018-05-29)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v7.0.0...v7.0.1)

**Closed issues:**

- Windows 8 IE 11 dropdowns don't work [\#205](https://github.com/Shopify/brooklyn/issues/205)

**Merged pull requests:**

- fix: Typo from \#218 [\#225](https://github.com/Shopify/brooklyn/pull/225) ([ruairiphackett](https://github.com/ruairiphackett))
- fix: change pointer event for windows 8 [\#224](https://github.com/Shopify/brooklyn/pull/224) ([jeremystephencobb](https://github.com/jeremystephencobb))

## [v7.0.0](https://github.com/Shopify/brooklyn/tree/v7.0.0) (2018-05-24)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v6.2.0...v7.0.0)

**Merged pull requests:**

- Goodbye CircleCI :wave: [\#222](https://github.com/Shopify/brooklyn/pull/222) ([shopify-admins](https://github.com/shopify-admins))
- Hello Shopify Build 👋 [\#221](https://github.com/Shopify/brooklyn/pull/221) ([shopify-admins](https://github.com/shopify-admins))
- Revert to gulp tasks [\#220](https://github.com/Shopify/brooklyn/pull/220) ([chrisberthe](https://github.com/chrisberthe))
- fix: Allow links for newsletter [\#218](https://github.com/Shopify/brooklyn/pull/218) ([ruairiphackett](https://github.com/ruairiphackett))
- Downgrade Node version to use LTS version 8.11.1 [\#216](https://github.com/Shopify/brooklyn/pull/216) ([huguestennier](https://github.com/huguestennier))

## [v6.2.0](https://github.com/Shopify/brooklyn/tree/v6.2.0) (2018-04-25)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v6.1.0...v6.2.0)

**Closed issues:**

- Featured product compare at price doesn't appear if 1st variant has none [\#199](https://github.com/Shopify/brooklyn/issues/199)
- Hamburger menu on desktop causing support debt [\#169](https://github.com/Shopify/brooklyn/issues/169)

**Merged pull requests:**

- fix: add info to header section [\#213](https://github.com/Shopify/brooklyn/pull/213) ([jeremystephencobb](https://github.com/jeremystephencobb))
- feat: Add Google Pay icon [\#211](https://github.com/Shopify/brooklyn/pull/211) ([ruairiphackett](https://github.com/ruairiphackett))
- fix: Price display issues [\#203](https://github.com/Shopify/brooklyn/pull/203) ([ruairiphackett](https://github.com/ruairiphackett))

## [v6.1.0](https://github.com/Shopify/brooklyn/tree/v6.1.0) (2018-04-03)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v6.0.0...v6.1.0)

**Closed issues:**

- Button colour is also colouring Chrome browser on Android [\#208](https://github.com/Shopify/brooklyn/issues/208)
- Implement SPB [\#202](https://github.com/Shopify/brooklyn/issues/202)
- Search box pushes icons off screen [\#163](https://github.com/Shopify/brooklyn/issues/163)

**Merged pull requests:**

- Add Smart Payment Buttons [\#207](https://github.com/Shopify/brooklyn/pull/207) ([martinamarien](https://github.com/martinamarien))
- Add missing {{ content\_for\_header }} [\#206](https://github.com/Shopify/brooklyn/pull/206) ([huguestennier](https://github.com/huguestennier))
- fix: Remove respond.js polyfill [\#204](https://github.com/Shopify/brooklyn/pull/204) ([ruairiphackett](https://github.com/ruairiphackett))
- Revert typography [\#200](https://github.com/Shopify/brooklyn/pull/200) ([martinamarien](https://github.com/martinamarien))

## [v6.0.0](https://github.com/Shopify/brooklyn/tree/v6.0.0) (2018-02-21)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v5.1.1...v6.0.0)

**Merged pull requests:**

- fix: remove box option in search settings [\#168](https://github.com/Shopify/brooklyn/pull/168) ([jeremystephencobb](https://github.com/jeremystephencobb))

## [v5.1.1](https://github.com/Shopify/brooklyn/tree/v5.1.1) (2018-02-21)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v5.1.0...v5.1.1)

**Closed issues:**

- Keyboard and focus a11y issues [\#186](https://github.com/Shopify/brooklyn/issues/186)
- Remove the default capitalization in headings [\#173](https://github.com/Shopify/brooklyn/issues/173)

**Merged pull requests:**

- fix: Escape inverted commas [\#201](https://github.com/Shopify/brooklyn/pull/201) ([ruairiphackett](https://github.com/ruairiphackett))
- Fixed heading capitalization default [\#181](https://github.com/Shopify/brooklyn/pull/181) ([martinamarien](https://github.com/martinamarien))

## [v5.1.0](https://github.com/Shopify/brooklyn/tree/v5.1.0) (2018-01-31)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v5.0.0...v5.1.0)

**Closed issues:**

- Menu style switching in the theme editor [\#110](https://github.com/Shopify/brooklyn/issues/110)
- Enhance Core Typography and Colors Management [\#73](https://github.com/Shopify/brooklyn/issues/73)

**Merged pull requests:**

- Color management [\#174](https://github.com/Shopify/brooklyn/pull/174) ([martinamarien](https://github.com/martinamarien))
- fix: common js fix for country options [\#172](https://github.com/Shopify/brooklyn/pull/172) ([bczegeny](https://github.com/bczegeny))
- fix: add missing payment icons to footer [\#154](https://github.com/Shopify/brooklyn/pull/154) ([matcaissy](https://github.com/matcaissy))

## [v5.0.0](https://github.com/Shopify/brooklyn/tree/v5.0.0) (2018-01-09)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v4.2.1...v5.0.0)

**Closed issues:**

- Three levels for main nav [\#81](https://github.com/Shopify/brooklyn/issues/81)

**Merged pull requests:**

- Add new liquid syntax for nested nav [\#82](https://github.com/Shopify/brooklyn/pull/82) ([huguestennier](https://github.com/huguestennier))

## [v4.2.1](https://github.com/Shopify/brooklyn/tree/v4.2.1) (2018-01-09)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v4.2.0...v4.2.1)

**Closed issues:**

- Changing color setting causes page to refresh twice \(multiple themes\) [\#167](https://github.com/Shopify/brooklyn/issues/167)
- Smart Devices converting Phone Numbers to illegible links [\#161](https://github.com/Shopify/brooklyn/issues/161)
- Password color font uses unset which is unsupported in IE11, iOS 9 [\#157](https://github.com/Shopify/brooklyn/issues/157)
- Customer account icon not showing in header on desktop if hamburger menu showing [\#153](https://github.com/Shopify/brooklyn/issues/153)
- Thumbnails Option for Brooklyn Product Page [\#24](https://github.com/Shopify/brooklyn/issues/24)

**Merged pull requests:**

- fix: ios device turns number into unstyled link [\#164](https://github.com/Shopify/brooklyn/pull/164) ([jeremystephencobb](https://github.com/jeremystephencobb))
- fix: amount_with_apostrophe_separator format [\#162](https://github.com/Shopify/brooklyn/pull/162) ([ruairiphackett](https://github.com/ruairiphackett))
- fix: show customer account icon when desktop menu collapses [\#160](https://github.com/Shopify/brooklyn/pull/160) ([jeremystephencobb](https://github.com/jeremystephencobb))
- Set password page font color to white [\#158](https://github.com/Shopify/brooklyn/pull/158) ([maximevaillancourt](https://github.com/maximevaillancourt))
- fix: product option logic [\#155](https://github.com/Shopify/brooklyn/pull/155) ([jeremystephencobb](https://github.com/jeremystephencobb))

## [v4.2.0](https://github.com/Shopify/brooklyn/tree/v4.2.0) (2017-11-28)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v4.1.1...v4.2.0)

**Closed issues:**

- Make sort_by the same as in admin [\#148](https://github.com/Shopify/brooklyn/issues/148)
- Google Structure Data test - ProductSection--product-template error [\#147](https://github.com/Shopify/brooklyn/issues/147)
- Can not remove item from cart page using quantity selectors [\#27](https://github.com/Shopify/brooklyn/issues/27)

**Merged pull requests:**

- fix: thumbnails schema rebase fix [\#156](https://github.com/Shopify/brooklyn/pull/156) ([matcaissy](https://github.com/matcaissy))
- feat: add product image thumbnails toggle setting [\#151](https://github.com/Shopify/brooklyn/pull/151) ([matcaissy](https://github.com/matcaissy))
- Set default collection "Sort by" value [\#150](https://github.com/Shopify/brooklyn/pull/150) ([maximevaillancourt](https://github.com/maximevaillancourt))
- fix: duplicate schema errors [\#149](https://github.com/Shopify/brooklyn/pull/149) ([jeremystephencobb](https://github.com/jeremystephencobb))
- feat: add to cart width setting [\#138](https://github.com/Shopify/brooklyn/pull/138) ([jeremystephencobb](https://github.com/jeremystephencobb))

## [v4.1.1](https://github.com/Shopify/brooklyn/tree/v4.1.1) (2017-10-30)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v4.1.0...v4.1.1)

**Closed issues:**

- Brookyln QA [\#146](https://github.com/Shopify/brooklyn/issues/146)
- Sort by undefined [\#143](https://github.com/Shopify/brooklyn/issues/143)
- Homepage featured collection 'Grid' setting creates javascript error causing slideshow to fail [\#141](https://github.com/Shopify/brooklyn/issues/141)
- Slideshow not full height hides menu color [\#139](https://github.com/Shopify/brooklyn/issues/139)

**Merged pull requests:**

- Fix "Sort by" errors in collection.js [\#145](https://github.com/Shopify/brooklyn/pull/145) ([maximevaillancourt](https://github.com/maximevaillancourt))
- fix: featured collection grid [\#142](https://github.com/Shopify/brooklyn/pull/142) ([chrisberthe](https://github.com/chrisberthe))
- Use the right header text color when hero_full_height is false [\#140](https://github.com/Shopify/brooklyn/pull/140) ([maximevaillancourt](https://github.com/maximevaillancourt))

## [v4.1.0](https://github.com/Shopify/brooklyn/tree/v4.1.0) (2017-10-27)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v4.0.1...v4.1.0)

**Merged pull requests:**

- Improve social sharing index [\#87](https://github.com/Shopify/brooklyn/pull/87) ([matcaissy](https://github.com/matcaissy))

## [v4.0.1](https://github.com/Shopify/brooklyn/tree/v4.0.1) (2017-10-26)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v4.0.0...v4.0.1)

**Merged pull requests:**

- Fix node rename [\#137](https://github.com/Shopify/brooklyn/pull/137) ([chrisberthe](https://github.com/chrisberthe))

## [v4.0.0](https://github.com/Shopify/brooklyn/tree/v4.0.0) (2017-10-26)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v3.0.0...v4.0.0)

**Closed issues:**

- Console error on add to cart [\#135](https://github.com/Shopify/brooklyn/issues/135)
- Slideshow overlay settings: confusing wording [\#130](https://github.com/Shopify/brooklyn/issues/130)
- Slideshow header text uses h1 color instead of slideshow text color [\#129](https://github.com/Shopify/brooklyn/issues/129)
- Navigation is not visible when there is no slideshow [\#125](https://github.com/Shopify/brooklyn/issues/125)
- Hamburger menu position on desktop vs mobile [\#33](https://github.com/Shopify/brooklyn/issues/33)
- Add sort by options to collection pages [\#25](https://github.com/Shopify/brooklyn/issues/25)

**Merged pull requests:**

- fix: Undefined error on cart drawer open [\#136](https://github.com/Shopify/brooklyn/pull/136) ([ruairiphackett](https://github.com/ruairiphackett))
- Change the hamburger menu color to match the header text color [\#134](https://github.com/Shopify/brooklyn/pull/134) ([maximevaillancourt](https://github.com/maximevaillancourt))
- Ignore package-lock.json [\#133](https://github.com/Shopify/brooklyn/pull/133) ([chrisberthe](https://github.com/chrisberthe))
- Improve Italian locale for collection sorting options [\#132](https://github.com/Shopify/brooklyn/pull/132) ([maximevaillancourt](https://github.com/maximevaillancourt))
- Add collection "Sort By" dropdown [\#131](https://github.com/Shopify/brooklyn/pull/131) ([maximevaillancourt](https://github.com/maximevaillancourt))
- Use headings text color for nav links color when there is no slideshow on the home page [\#128](https://github.com/Shopify/brooklyn/pull/128) ([maximevaillancourt](https://github.com/maximevaillancourt))
- Prevent the "Headings" color setting from overriding the slideshow's text color [\#126](https://github.com/Shopify/brooklyn/pull/126) ([maximevaillancourt](https://github.com/maximevaillancourt))
- Update Brooklyn with pt-BR [\#121](https://github.com/Shopify/brooklyn/pull/121) ([gabrielajungblut](https://github.com/gabrielajungblut))
- Update linting and add prettier [\#118](https://github.com/Shopify/brooklyn/pull/118) ([huguestennier](https://github.com/huguestennier))
- Move jQuery to assets [\#114](https://github.com/Shopify/brooklyn/pull/114) ([ruairiphackett](https://github.com/ruairiphackett))
- feat: add Italian translations [\#111](https://github.com/Shopify/brooklyn/pull/111) ([matcaissy](https://github.com/matcaissy))
- Move hamburger icon [\#101](https://github.com/Shopify/brooklyn/pull/101) ([ruairiphackett](https://github.com/ruairiphackett))

## [v3.0.0](https://github.com/Shopify/brooklyn/tree/v3.0.0) (2017-10-10)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v2.7.0...v3.0.0)

**Merged pull requests:**

- V2.7.0 release [\#123](https://github.com/Shopify/brooklyn/pull/123) ([ruairiphackett](https://github.com/ruairiphackett))
- Breaking change: Add a setting to use the accent font-family on subheadings [\#106](https://github.com/Shopify/brooklyn/pull/106) ([maximevaillancourt](https://github.com/maximevaillancourt))
- Breaking change: Improve color settings [\#105](https://github.com/Shopify/brooklyn/pull/105) ([maximevaillancourt](https://github.com/maximevaillancourt))
- Breaking change: Improve header and slideshow settings \(colors & logo\) [\#104](https://github.com/Shopify/brooklyn/pull/104) ([maximevaillancourt](https://github.com/maximevaillancourt))

## [v2.7.0](https://github.com/Shopify/brooklyn/tree/v2.7.0) (2017-10-10)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v2.6.4...v2.7.0)

**Closed issues:**

- Wrong variant is being added to the cart on older version of Brooklyn [\#112](https://github.com/Shopify/brooklyn/issues/112)

**Merged pull requests:**

- Fix Circle CI issues [\#120](https://github.com/Shopify/brooklyn/pull/120) ([chrisberthe](https://github.com/chrisberthe))
- Add Theme Kit install to CircleCI [\#117](https://github.com/Shopify/brooklyn/pull/117) ([chrisberthe](https://github.com/chrisberthe))
- Add CircleCI 2.0 [\#116](https://github.com/Shopify/brooklyn/pull/116) ([chrisberthe](https://github.com/chrisberthe))
- Product page layout adjustments [\#108](https://github.com/Shopify/brooklyn/pull/108) ([maximevaillancourt](https://github.com/maximevaillancourt))
- \[Section Parity\] Redesign rich text [\#86](https://github.com/Shopify/brooklyn/pull/86) ([ruairiphackett](https://github.com/ruairiphackett))

## [v2.6.4](https://github.com/Shopify/brooklyn/tree/v2.6.4) (2017-09-21)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v2.6.3...v2.6.4)

**Closed issues:**

- Variant options as a drop down [\#50](https://github.com/Shopify/brooklyn/issues/50)

**Merged pull requests:**

- Addition for optional button/dropdown variant selector [\#70](https://github.com/Shopify/brooklyn/pull/70) ([drabbytux](https://github.com/drabbytux))

## [v2.6.3](https://github.com/Shopify/brooklyn/tree/v2.6.3) (2017-09-19)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v2.6.2...v2.6.3)

**Closed issues:**

- Variants not updating for featured product [\#97](https://github.com/Shopify/brooklyn/issues/97)
- Dropdown are broken on android/firefox [\#96](https://github.com/Shopify/brooklyn/issues/96)
- Multiple featured products with same variant names don't work [\#94](https://github.com/Shopify/brooklyn/issues/94)
- Drawer cart is broken in Edge 15 [\#61](https://github.com/Shopify/brooklyn/issues/61)
- Add Quantity Selector Setting [\#45](https://github.com/Shopify/brooklyn/issues/45)

**Merged pull requests:**

- Update ja.json [\#100](https://github.com/Shopify/brooklyn/pull/100) ([arisaueno](https://github.com/arisaueno))
- Update variant price and image on featured product [\#99](https://github.com/Shopify/brooklyn/pull/99) ([matcaissy](https://github.com/matcaissy))
- remove fastclick [\#98](https://github.com/Shopify/brooklyn/pull/98) ([matcaissy](https://github.com/matcaissy))
- Update theme version to 2.6.2 [\#95](https://github.com/Shopify/brooklyn/pull/95) ([matcaissy](https://github.com/matcaissy))
- fix: update customer order tracking url [\#88](https://github.com/Shopify/brooklyn/pull/88) ([bczegeny](https://github.com/bczegeny))
- Checkbox added for quantity selector [\#71](https://github.com/Shopify/brooklyn/pull/71) ([drabbytux](https://github.com/drabbytux))

## [v2.6.2](https://github.com/Shopify/brooklyn/tree/v2.6.2) (2017-08-24)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v2.6.1...v2.6.2)

**Closed issues:**

- Add to cart button doesn't disable for unavailable and sold out variants [\#85](https://github.com/Shopify/brooklyn/issues/85)

**Merged pull requests:**

- Update theme version to 2.6.1 [\#93](https://github.com/Shopify/brooklyn/pull/93) ([matcaissy](https://github.com/matcaissy))
- Fix for sold out variants [\#90](https://github.com/Shopify/brooklyn/pull/90) ([seanconnolly1105](https://github.com/seanconnolly1105))
- Add icomoon icon font update instructions [\#84](https://github.com/Shopify/brooklyn/pull/84) ([ruairiphackett](https://github.com/ruairiphackett))

## [v2.6.1](https://github.com/Shopify/brooklyn/tree/v2.6.1) (2017-08-23)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v2.6.0...v2.6.1)

**Merged pull requests:**

- fix map password stings [\#92](https://github.com/Shopify/brooklyn/pull/92) ([matcaissy](https://github.com/matcaissy))
- Brooklyn 2.6.0 [\#89](https://github.com/Shopify/brooklyn/pull/89) ([matcaissy](https://github.com/matcaissy))

## [v2.6.0](https://github.com/Shopify/brooklyn/tree/v2.6.0) (2017-08-22)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v2.5.1...v2.6.0)

**Merged pull requests:**

- \[Section Parity\] Add store info [\#83](https://github.com/Shopify/brooklyn/pull/83) ([matcaissy](https://github.com/matcaissy))
- Update theme version 2.5.1 [\#80](https://github.com/Shopify/brooklyn/pull/80) ([matcaissy](https://github.com/matcaissy))

## [v2.5.1](https://github.com/Shopify/brooklyn/tree/v2.5.1) (2017-08-02)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v2.5.0...v2.5.1)

**Closed issues:**

- \[Sections Standardization\] Video [\#53](https://github.com/Shopify/brooklyn/issues/53)
- Navigation dropdowns hidden behind sections when there's no slider [\#32](https://github.com/Shopify/brooklyn/issues/32)

**Merged pull requests:**

- \[Section Parity\] Image with text content [\#77](https://github.com/Shopify/brooklyn/pull/77) ([ruairiphackett](https://github.com/ruairiphackett))
- update theme version to 2.5.0 [\#74](https://github.com/Shopify/brooklyn/pull/74) ([matcaissy](https://github.com/matcaissy))
- fix for dropdown menu [\#69](https://github.com/Shopify/brooklyn/pull/69) ([jeremystephencobb](https://github.com/jeremystephencobb))
- \[Sections Standardization\] Video [\#57](https://github.com/Shopify/brooklyn/pull/57) ([huguestennier](https://github.com/huguestennier))

## [v2.5.0](https://github.com/Shopify/brooklyn/tree/v2.5.0) (2017-07-13)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v2.4.0...v2.5.0)

**Closed issues:**

- Font association broken for Playful [\#64](https://github.com/Shopify/brooklyn/issues/64)
- \[Sections Standardization\] Featured Product [\#58](https://github.com/Shopify/brooklyn/issues/58)
- slideshow text colors not working as expected [\#48](https://github.com/Shopify/brooklyn/issues/48)
- The slideshow image been cropped on mobile [\#44](https://github.com/Shopify/brooklyn/issues/44)
- Image improvements audit [\#8](https://github.com/Shopify/brooklyn/issues/8)

**Merged pull requests:**

- \[Sections Standardization\] add featured blog post section [\#66](https://github.com/Shopify/brooklyn/pull/66) ([matcaissy](https://github.com/matcaissy))
- Add Quicksand, fix Playful default [\#65](https://github.com/Shopify/brooklyn/pull/65) ([melissaperreault](https://github.com/melissaperreault))
- Add featured product section [\#63](https://github.com/Shopify/brooklyn/pull/63) ([MaxMusing](https://github.com/MaxMusing))
- feat: bundling changelog with theme [\#62](https://github.com/Shopify/brooklyn/pull/62) ([bczegeny](https://github.com/bczegeny))
- update theme version to 2.4.0 [\#60](https://github.com/Shopify/brooklyn/pull/60) ([matcaissy](https://github.com/matcaissy))
- \[Section Parity\] Newsletter content changes [\#56](https://github.com/Shopify/brooklyn/pull/56) ([ruairiphackett](https://github.com/ruairiphackett))
- Responsive images [\#10](https://github.com/Shopify/brooklyn/pull/10) ([matcaissy](https://github.com/matcaissy))

## [v2.4.0](https://github.com/Shopify/brooklyn/tree/v2.4.0) (2017-06-15)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v2.2.0...v2.4.0)

**Closed issues:**

- test [\#42](https://github.com/Shopify/brooklyn/issues/42)
- Scrolls to incorrect Variant Image when Product Description is static [\#41](https://github.com/Shopify/brooklyn/issues/41)
- \[Sections Standardization\] Announcement Bar [\#39](https://github.com/Shopify/brooklyn/issues/39)
- Product page with colour variant images acting weird [\#36](https://github.com/Shopify/brooklyn/issues/36)
- Content for new preset: Playful [\#31](https://github.com/Shopify/brooklyn/issues/31)
- Newsletter background visibility [\#26](https://github.com/Shopify/brooklyn/issues/26)

**Merged pull requests:**

- update theme version 2.3.0 [\#59](https://github.com/Shopify/brooklyn/pull/59) ([matcaissy](https://github.com/matcaissy))
- Add Japanese translations [\#55](https://github.com/Shopify/brooklyn/pull/55) ([SebastianSzturo](https://github.com/SebastianSzturo))
- Fix announcement bar schema naming and update hover color [\#54](https://github.com/Shopify/brooklyn/pull/54) ([MaxMusing](https://github.com/MaxMusing))
- Product grid responsive [\#52](https://github.com/Shopify/brooklyn/pull/52) ([ruairiphackett](https://github.com/ruairiphackett))
- Add playful preset [\#46](https://github.com/Shopify/brooklyn/pull/46) ([chrisberthe](https://github.com/chrisberthe))
- Fix variant scroll [\#43](https://github.com/Shopify/brooklyn/pull/43) ([ruairiphackett](https://github.com/ruairiphackett))
- Add announcement bar [\#40](https://github.com/Shopify/brooklyn/pull/40) ([MaxMusing](https://github.com/MaxMusing))
- Update to using Yarn [\#38](https://github.com/Shopify/brooklyn/pull/38) ([chrisberthe](https://github.com/chrisberthe))
- Fix for currency precision bug [\#37](https://github.com/Shopify/brooklyn/pull/37) ([tylerrowsell](https://github.com/tylerrowsell))
- remove bgset, fade-in and add small img fallbacks [\#35](https://github.com/Shopify/brooklyn/pull/35) ([matcaissy](https://github.com/matcaissy))
- review wins from Thomas [\#34](https://github.com/Shopify/brooklyn/pull/34) ([matcaissy](https://github.com/matcaissy))
- only loop first slide image on noscript [\#30](https://github.com/Shopify/brooklyn/pull/30) ([matcaissy](https://github.com/matcaissy))
- add better no img fallback on grid [\#29](https://github.com/Shopify/brooklyn/pull/29) ([matcaissy](https://github.com/matcaissy))
- responsive images round 1 review [\#28](https://github.com/Shopify/brooklyn/pull/28) ([matcaissy](https://github.com/matcaissy))
- add lazysizes to article image [\#22](https://github.com/Shopify/brooklyn/pull/22) ([matcaissy](https://github.com/matcaissy))
- add lazysizes to collection grid items [\#21](https://github.com/Shopify/brooklyn/pull/21) ([matcaissy](https://github.com/matcaissy))
- add bgset lazysizes to collection hero image \[JS bgset\] [\#20](https://github.com/Shopify/brooklyn/pull/20) ([matcaissy](https://github.com/matcaissy))
- add lazysizes to product grid images \[JS\] [\#19](https://github.com/Shopify/brooklyn/pull/19) ([matcaissy](https://github.com/matcaissy))
- update theme version to 2.2.0 [\#18](https://github.com/Shopify/brooklyn/pull/18) ([matcaissy](https://github.com/matcaissy))
- Updating Slate package [\#17](https://github.com/Shopify/brooklyn/pull/17) ([thecatmelon](https://github.com/thecatmelon))
- Responsive images product page \[JS\] [\#16](https://github.com/Shopify/brooklyn/pull/16) ([matcaissy](https://github.com/matcaissy))
- Add product image retina [\#12](https://github.com/Shopify/brooklyn/pull/12) ([matcaissy](https://github.com/matcaissy))
- add responsive slideshow images \[JS\] [\#11](https://github.com/Shopify/brooklyn/pull/11) ([matcaissy](https://github.com/matcaissy))
- Add Collections List template [\#4](https://github.com/Shopify/brooklyn/pull/4) ([ruairiphackett](https://github.com/ruairiphackett))

## [v2.2.0](https://github.com/Shopify/brooklyn/tree/v2.2.0) (2017-04-06)

[Full Changelog](https://github.com/Shopify/brooklyn/compare/v2.1.3...v2.2.0)

**Merged pull requests:**

- update theme version to 2.1.4 [\#15](https://github.com/Shopify/brooklyn/pull/15) ([matcaissy](https://github.com/matcaissy))
- Escape text settings [\#13](https://github.com/Shopify/brooklyn/pull/13) ([ruairiphackett](https://github.com/ruairiphackett))
- add lazysizes lib [\#9](https://github.com/Shopify/brooklyn/pull/9) ([matcaissy](https://github.com/matcaissy))
- Replace linting with @shopify/theme-lint [\#6](https://github.com/Shopify/brooklyn/pull/6) ([chrisberthe](https://github.com/chrisberthe))
- Update circle.yml [\#5](https://github.com/Shopify/brooklyn/pull/5) ([t-kelly](https://github.com/t-kelly))
- Add Circle CI config [\#3](https://github.com/Shopify/brooklyn/pull/3) ([chrisberthe](https://github.com/chrisberthe))
- update theme version to 2.1.3 [\#2](https://github.com/Shopify/brooklyn/pull/2) ([matcaissy](https://github.com/matcaissy))

## [v2.1.3](https://github.com/Shopify/brooklyn/tree/v2.1.3) (2017-03-14)

**Merged pull requests:**

- Add .gitignore file [\#1](https://github.com/Shopify/brooklyn/pull/1) ([ruairiphackett](https://github.com/ruairiphackett))

\* _This Change Log was automatically generated by [github_changelog_generator](https://github.com/skywinder/Github-Changelog-Generator)_
